using System;
using System.IO;
using TMPro;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Yinya;

public static class YinyaSceneBuilder
{
    public const string ScenePath = "Assets/Scenes/YinyaPrototype.unity";
    private const string Art = "Assets/Art/Figma/";
    private static readonly Color Ink = Hex("343A48"), Muted = Hex("68717C"), Brand = Hex("46566A");
    private static readonly Color Lime = Hex("C8D74E"), Cream = Hex("FCFFE0"), Gold = Hex("F0D585");
    private static TMP_FontAsset regular, bold;
    private static Sprite rounded, circle;

    [MenuItem("Yinya/Build Prototype")]
    public static void Build()
    {
        if (File.Exists(YinyaOfflineBuilder.ScenePath)) { YinyaOfflineBuilder.Build(); return; }
        if (EditorApplication.isPlaying) { Debug.LogWarning("Stop Play Mode before building."); return; }
        if (File.Exists(ScenePath))
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            EditorSceneManager.OpenScene(ScenePath);
            Debug.Log("Opened existing prototype. Existing scene changes were preserved.");
            return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory("Assets/Art/Generated");
        Directory.CreateDirectory("Assets/Prefabs");
        AssetDatabase.Refresh();
        PrepareResources();
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var camera = new GameObject("Main Camera", typeof(Camera)).GetComponent<Camera>();
        camera.tag = "MainCamera"; camera.orthographic = true;
        camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = Cream;
        camera.transform.position = new Vector3(0, 0, -10);
        var appRoot = new GameObject("AppRoot");
        var input = appRoot.AddComponent<ToyInput>();
        var audio = appRoot.AddComponent<MusicAudio>();
        audio.input = input;
        audio.notes = new AudioClip[5]; audio.voices = new AudioSource[5];
        for (int i = 0; i < 5; i++)
        {
            audio.notes[i] = AssetDatabase.LoadAssetAtPath<AudioClip>($"Assets/Audio/Notes/{i}.wav");
            if (audio.notes[i] == null) throw new InvalidOperationException("Missing generated note " + i);
            var voice = appRoot.AddComponent<AudioSource>();
            voice.playOnAwake = false; voice.spatialBlend = 0; voice.volume = .55f;
            audio.voices[i] = voice;
        }
        appRoot.AddComponent<AudioListener>();
        var app = appRoot.AddComponent<YinyaApp>(); app.input = input; app.audioEngine = audio;
        var canvasGO = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasGO.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGO.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1194, 834); scaler.matchWidthOrHeight = .5f;
        var backdrop = Panel(canvasGO.transform, "Backdrop", 0, 0, 1194, 834, Cream);
        Stretch(backdrop); backdrop.GetComponent<Image>().type = Image.Type.Simple;
        var safe = Rect(canvasGO.transform, "SafeArea", 0, 0, 1194, 834); Stretch(safe);
        safe.gameObject.AddComponent<SafeAreaFit>();
        var frame = Rect(safe, "DesignFrame", 0, 0, 1194, 834);
        frame.anchorMin = frame.anchorMax = new Vector2(.5f,.5f); frame.pivot = new Vector2(.5f,.5f); frame.anchoredPosition = Vector2.zero;
        frame.gameObject.AddComponent<DesignFrameFit>();
        app.homePage = Home(frame, app).gameObject;
        app.freePage = FreePlay(frame, app).gameObject;
        Popup(frame, app);
        app.freePage.SetActive(false); app.popup.SetActive(false);
        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        PlayerSettings.companyName = "Yinya"; PlayerSettings.productName = "Yinya Music";
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToPortrait = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Debug.Log("Yinya prototype built: " + ScenePath);
    }

    private static RectTransform Home(Transform parent, YinyaApp app)
    {
        var page = Panel(parent, "HomePage", 0, 0, 1194, 834, Lime);
        Panel(page, "HomeSurface", 10, 10, 1174, 814, Cream);
        app.clockHome = Label(page, "Clock", "", 46, 19, 450, 18, 12, Ink);
        var emblem = Panel(page, "BrandMark", 46, 59, 52, 52, Lime);
        emblem.GetComponent<Image>().sprite=circle;emblem.GetComponent<Image>().type=Image.Type.Simple;
        ArtImage(emblem, "music", 15, 15, 22, 22);
        Label(page,"Title","Yinya · A little music world",114,51,740,45,30,Ink,true);
        Label(page,"Subtitle","A melody for every feeling",114,96,740,23,15,Muted);
        Navigation(page, app, true);
        string[] titles = { "Music games", "Emotional music", "Free creation" };
        string[] subtitles = { "Listen, tap and take turns", "Every feeling deserves to be heard", "Tap freely and make your music" };
        string[] labels = { "Play music", "Explore my feelings", "Explore sounds" };
        Color[] colors = { Hex("F9A561"), Lime, Hex("F3D558") };
        for (int i=0; i<3; i++)
        {
            var card = Panel(page, "Entry_" + i, 61 + i*370, 222, 350, 480, colors[i]);
            if(i==0) ArtImage(card,"drum",-92.5f,30.5f,531,266);
            if(i==1) ArtImage(card,"forest",-1.5f,62.5f,358,162);
            if(i==2) ArtImage(card,"piano",-57.5f,57.5f,462,209);
            Label(card,"Title",titles[i],16,268,318,39,26,Color.white,true,TextAlignmentOptions.Center);
            Label(card,"Subtitle",subtitles[i],16,310,318,48,16,Hex("507660"),false,TextAlignmentOptions.Top);
            int entry=i;
            var button=Button(card,"EntryButton",labels[i],20,391,310,56,Color.white,i==2?Hex("919F20"):i==0?colors[i]:Hex("C28958"));
            if(entry==2) UnityEventTools.AddPersistentListener(button.onClick,app.ShowFreePlay);
            else UnityEventTools.AddStringPersistentListener(button.onClick,app.ShowNotice,titles[i]);
        }
        return page;
    }

    private static RectTransform FreePlay(Transform parent, YinyaApp app)
    {
        var page=Panel(parent,"FreePlayPage",0,0,1194,834,Gold);
        app.clockFree=Label(page,"Clock","",36,9,450,18,12,Ink);
        var back=IconButton(page,"Back","back",36,49,52,Color.white);
        UnityEventTools.AddPersistentListener(back.onClick,app.ShowHome);
        Label(page,"Title","Free creation",104,41,760,45,30,Ink,true);
        Label(page,"Subtitle","Every tap is a little creation",104,86,760,23,15,Muted);
        Navigation(page,app,false);
        var card=Panel(page,"InstrumentCard",52,133,300,565,Hex("FFEEBD"));
        Panel(card,"CurrentSoundPill",24,24,145,40,Color.white);
        Label(card,"CurrentSound","Current sound",40,32,120,24,16,Ink,true);
        ArtImage(card,"xylophone",24,84,252,143);
        Label(card,"Instrument","Warm xylophone",24,244,252,42,28,Ink,true);
        Label(card,"Description","Do · Re · Mi · So · La\nFive notes, endless possibilities.",24,306,252,82,16,Muted);
        NoticeButton(card,"ChangeInstrument","Change instrument",24,408,252,56,Color.white,Brand,app);
        NoticeButton(card,"Record","Record my music",24,484,252,56,Brand,Color.white,app);
        NoticeButton(page,"MyMusic","My music",953,746,194,56,Color.white,Brand,app);
        var play=Panel(page,"PlayableInstrument",380,133,762,565,Hex("FFF6E4"));
        Label(play,"Hint","A little melody, made by you",28,24,706,38,25,Ink,true);
        Label(play,"Instruction","Touch the keys · or use 1 2 3 4 5",28,69,706,27,16,Muted);
        app.noteLabel=Label(play,"ActiveNote","Ready to play",28,113,706,64,42,Brand,true,TextAlignmentOptions.Center);
        Color[] colors={Hex("F9A561"),Hex("C8D74E"),Hex("9EBCE0"),Hex("D5BDF9"),Hex("F0D585")};
        string[] names={"Do","Re","Mi","So","La"};
        for(int i=0;i<5;i++)
        {
            var key=Panel(play,"Key_"+i,28+i*143,208+i*10,134,260-i*10,colors[i]);
            key.GetComponent<Image>().raycastTarget=true;
            var script=key.gameObject.AddComponent<PianoKey>();
            script.input=app.input;script.key=i;script.face=key.GetComponent<Image>();script.normal=colors[i];
            Label(key,"Note",names[i],0,34,134,48,30,Ink,true,TextAlignmentOptions.Center);
            Label(key,"KeyNumber",(i+1).ToString(),0,193-i*10,134,24,16,Brand,false,TextAlignmentOptions.Center);
        }
        app.countLabel=Label(play,"TapCount","Your first sound is waiting",28,506,706,28,16,Muted,false,TextAlignmentOptions.Center);
        return page;
    }

    private static void Navigation(Transform page,YinyaApp app,bool home)
    {
        var nav=Rect(page,"Navigation",930,51,228,48);
        string[] icons={"bluetooth","home","profile","settings"};
        string[] topics={"Connect your toy","","My companion","Sound settings"};
        for(int i=0;i<4;i++)
        {
            var button=IconButton(nav,icons[i],icons[i],i*60,0,48,home?Hex("E2EB97"):Color.white);
            if(i==1) UnityEventTools.AddPersistentListener(button.onClick,app.ShowHome);
            else UnityEventTools.AddStringPersistentListener(button.onClick,app.ShowNotice,topics[i]);
        }
    }

    private static void Popup(Transform parent,YinyaApp app)
    {
        var layer=Panel(parent,"PopupLayer",0,0,1194,834,new Color(0.20f,0.23f,0.28f,.42f));
        layer.GetComponent<Image>().type=Image.Type.Simple;layer.GetComponent<Image>().raycastTarget=true;
        var panel=Panel(layer,"Dialog",297,227,600,380,Hex("FFF6E4"));
        app.popup=layer.gameObject;
        app.popupTitle=Label(panel,"Title","",32,28,536,45,28,Ink,true);
        app.popupBody=Label(panel,"Body","",32,90,536,100,18,Muted);
        var volume=Rect(panel,"VolumeControls",32,205,536,55);app.volumeControls=volume.gameObject;
        Label(volume,"Label","Volume",0,0,120,30,18,Ink);
        var track=Panel(volume,"VolumeSlider",130,6,390,18,Hex("E2EB97"));track.GetComponent<Image>().raycastTarget=true;
        var slider=track.gameObject.AddComponent<Slider>();
        var fill=Panel(track,"Fill",0,0,390,18,Lime);Stretch(fill);
        var handle=Panel(track,"Handle",0,-5,28,28,Brand);
        slider.fillRect=fill;slider.handleRect=handle;slider.targetGraphic=handle.GetComponent<Image>();
        slider.minValue=0;slider.maxValue=1;slider.value=.55f;app.volumeSlider=slider;
        var close=Button(panel,"Close","Back to music",32,292,536,56,Brand,Color.white);
        UnityEventTools.AddPersistentListener(close.onClick,app.ClosePopup);
    }

    private static void NoticeButton(Transform parent,string name,string title,float x,float y,float w,float h,Color bg,Color fg,YinyaApp app)
    { var b=Button(parent,name,title,x,y,w,h,bg,fg);UnityEventTools.AddStringPersistentListener(b.onClick,app.ShowNotice,title); }
    private static Button IconButton(Transform p,string name,string icon,float x,float y,float size,Color color)
    { var root=Panel(p,name,x,y,size,size,color);root.GetComponent<Image>().sprite=circle;root.GetComponent<Image>().type=Image.Type.Simple; var b=root.gameObject.AddComponent<Button>();b.targetGraphic=root.GetComponent<Image>();root.GetComponent<Image>().raycastTarget=true;
      float s=icon=="settings"?17:22;ArtImage(root,icon,(size-s)/2,(size-s)/2,s,s);return b; }
    private static Button Button(Transform p,string name,string text,float x,float y,float w,float h,Color bg,Color fg)
    {var root=Panel(p,name,x,y,w,h,bg);var b=root.gameObject.AddComponent<Button>();b.targetGraphic=root.GetComponent<Image>();b.targetGraphic.raycastTarget=true;
     Label(root,"Label",text,12,0,w-24,h,18,fg,false,TextAlignmentOptions.Center);return b;}
    private static TMP_Text Label(Transform p,string name,string text,float x,float y,float w,float h,int size,Color color,bool strong=false,TextAlignmentOptions align=TextAlignmentOptions.TopLeft)
    {var r=Rect(p,name,x,y,w,h);var t=r.gameObject.AddComponent<TextMeshProUGUI>();t.font=strong?bold:regular;t.text=text;t.fontSize=size;t.color=color;t.alignment=align;t.raycastTarget=false;t.enableWordWrapping=true;return t;}
    private static void ArtImage(Transform p,string name,float x,float y,float w,float h)
    {var r=Rect(p,"Figma_"+name,x,y,w,h);var img=r.gameObject.AddComponent<Image>();img.sprite=AssetDatabase.LoadAssetAtPath<Sprite>(Art+name+".png");if(img.sprite==null)throw new InvalidOperationException("Missing Figma asset: "+name);img.preserveAspect=true;img.raycastTarget=false;}
    private static RectTransform Panel(Transform p,string name,float x,float y,float w,float h,Color color)
    {var r=Rect(p,name,x,y,w,h);var img=r.gameObject.AddComponent<Image>();img.sprite=rounded;img.type=Image.Type.Sliced;img.color=color;img.raycastTarget=false;return r;}
    private static RectTransform Rect(Transform p,string name,float x,float y,float w,float h)
    {var r=new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();r.SetParent(p,false);r.anchorMin=r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-y);r.sizeDelta=new Vector2(w,h);return r;}
    private static void Stretch(RectTransform r){r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=r.offsetMax=Vector2.zero;}
    private static Color Hex(string s){ColorUtility.TryParseHtmlString("#"+s,out Color c);return c;}

    private static void PrepareResources()
    {
        foreach(string file in Directory.GetFiles(Art,"*.png"))
        {
            var importer=(TextureImporter)AssetImporter.GetAtPath(file);importer.textureType=TextureImporterType.Sprite;
            importer.alphaIsTransparency=true;importer.mipmapEnabled=false;importer.textureCompression=TextureImporterCompression.Uncompressed;importer.SaveAndReimport();
        }
        string path="Assets/Art/Generated/Rounded.png";
        if(!File.Exists(path))
        {
            var texture=new Texture2D(64,64,TextureFormat.RGBA32,false);
            for(int y=0;y<64;y++)for(int x=0;x<64;x++)
            {float dx=Mathf.Max(20-x,0,x-43),dy=Mathf.Max(20-y,0,y-43);float alpha=Mathf.Clamp01(20.5f-Mathf.Sqrt(dx*dx+dy*dy));texture.SetPixel(x,y,new Color(1,1,1,alpha));}
            texture.Apply();File.WriteAllBytes(path,texture.EncodeToPNG());UnityEngine.Object.DestroyImmediate(texture);AssetDatabase.ImportAsset(path);
        }
        var ti=(TextureImporter)AssetImporter.GetAtPath(path);ti.textureType=TextureImporterType.Sprite;ti.spriteBorder=new Vector4(22,22,22,22);ti.alphaIsTransparency=true;ti.mipmapEnabled=false;ti.SaveAndReimport();
        rounded=AssetDatabase.LoadAssetAtPath<Sprite>(path);
        string circlePath="Assets/Art/Generated/Circle.png";
        if(!File.Exists(circlePath))
        {
            var texture=new Texture2D(64,64,TextureFormat.RGBA32,false);
            for(int y=0;y<64;y++)for(int x=0;x<64;x++)
                texture.SetPixel(x,y,new Color(1,1,1,Mathf.Clamp01(31.5f-Vector2.Distance(new Vector2(x,y),new Vector2(31.5f,31.5f)))));
            texture.Apply();File.WriteAllBytes(circlePath,texture.EncodeToPNG());UnityEngine.Object.DestroyImmediate(texture);AssetDatabase.ImportAsset(circlePath);
        }
        var ci=(TextureImporter)AssetImporter.GetAtPath(circlePath);ci.textureType=TextureImporterType.Sprite;ci.alphaIsTransparency=true;ci.mipmapEnabled=false;ci.SaveAndReimport();
        circle=AssetDatabase.LoadAssetAtPath<Sprite>(circlePath);
        regular=Font("Regular");bold=Font("Bold");
    }
    private static TMP_FontAsset Font(string weight)
    {
        string path="Assets/Fonts/Yinya"+weight+".asset";var asset=AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(path);if(asset!=null)return asset;
        var font=AssetDatabase.LoadAssetAtPath<Font>("Assets/Fonts/NotoSansSC-"+weight+".otf");
        asset=TMP_FontAsset.CreateFontAsset(font);asset.name="Yinya"+weight;
        AssetDatabase.CreateAsset(asset,path);AssetDatabase.AddObjectToAsset(asset.material,asset);
        foreach(var atlas in asset.atlasTextures)AssetDatabase.AddObjectToAsset(atlas,asset);
        asset.TryAddCharacters("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ·,.:/—&!?()",out string missing);
        EditorUtility.SetDirty(asset);return asset;
    }
}
