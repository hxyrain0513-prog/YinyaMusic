using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class YinyaWebBuild
{
    [MenuItem("Yinya/Build iPad Browser Demo")]
    public static void Build()
    {
        if(EditorApplication.isPlaying)throw new InvalidOperationException("Stop Play Mode before building.");
        if(!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.WebGL,BuildTarget.WebGL))
            throw new InvalidOperationException("Install WebGL Build Support for this Unity Editor.");
        string output=Environment.GetEnvironmentVariable("YINYA_WEB_OUTPUT");
        if(string.IsNullOrWhiteSpace(output))output=Path.GetFullPath("Releases/WebGL-iPad");
        PlayerSettings.companyName="Yinya";PlayerSettings.productName="Yinya Music";
        PlayerSettings.WebGL.template="PROJECT:YinyaTablet";
        PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Gzip;
        PlayerSettings.WebGL.decompressionFallback=true;
        PlayerSettings.WebGL.nameFilesAsHashes=true;
        PlayerSettings.WebGL.dataCaching=true;
        PlayerSettings.WebGL.threadsSupport=false;
        PlayerSettings.WebGL.initialMemorySize=256;
        PlayerSettings.WebGL.maximumMemorySize=512;
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.WebGL,ScriptingImplementation.IL2CPP);
        PlayerSettings.defaultWebScreenWidth=1194;PlayerSettings.defaultWebScreenHeight=834;
        var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{
            scenes=new[]{"Assets/Scenes/YinyaOffline.unity"},locationPathName=output,
            target=BuildTarget.WebGL,options=BuildOptions.None
        });
        if(report.summary.result!=BuildResult.Succeeded)throw new InvalidOperationException("Web build failed: "+report.summary.result);
        File.WriteAllText(Path.Combine(output,"yinya-demo.json"),"{\"app\":\"Yinya\",\"platform\":\"WebGL\",\"version\":\"0.1.0\"}");
        Debug.Log("YINYA_WEB_BUILD_SUCCEEDED: "+output);
    }
}
