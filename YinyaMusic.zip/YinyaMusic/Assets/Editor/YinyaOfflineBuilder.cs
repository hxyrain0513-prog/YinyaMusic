using System;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Yinya;

public static class YinyaOfflineBuilder
{
    public const string ScenePath="Assets/Scenes/YinyaOffline.unity";
    [MenuItem("Yinya/Build Offline App")]
    public static void Build()
    {
        if(EditorApplication.isPlaying){Debug.LogWarning("Stop Play Mode before building the offline app.");return;}
        if(!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())return;
        if(File.Exists(ScenePath)){EditorSceneManager.OpenScene(ScenePath);Debug.Log("Opened existing offline app; no scene was overwritten.");return;}
        ImportArt();
        var regular=AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/Fonts/YinyaRegular.asset");
        var bold=AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/Fonts/YinyaBold.asset");
        if(regular==null||bold==null)throw new InvalidOperationException("Build the initial prototype resources first.");
        var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        var camera=new GameObject("Main Camera",typeof(Camera)).GetComponent<Camera>();camera.tag="MainCamera";
        camera.orthographic=true;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=OfflineUI.Cream;camera.transform.position=new Vector3(0,0,-10);
        camera.gameObject.AddComponent<AudioListener>();
        var root=new GameObject("OfflineAppRoot");var input=root.AddComponent<ToyInput>();
        var app=root.AddComponent<OfflineApp>();app.input=input;app.regularFont=regular;app.boldFont=bold;
        app.roundSprite=AssetDatabase.LoadAssetAtPath<Sprite>("Assets/Art/Generated/Rounded.png");
        app.circleSprite=AssetDatabase.LoadAssetAtPath<Sprite>("Assets/Art/Generated/Circle.png");
        app.pillSprite=AssetDatabase.LoadAssetAtPath<Sprite>("Assets/Art/Generated/Capsule.png");
        var art=new List<NamedArt>();
        foreach(string directory in new[]{"Assets/Art/Figma","Assets/Art/Offline"})
            foreach(string file in Directory.GetFiles(directory,"*.png"))art.Add(new NamedArt{name=Path.GetFileNameWithoutExtension(file),sprite=AssetDatabase.LoadAssetAtPath<Sprite>(file)});
        app.assets=art.ToArray();
        string[] names={"Warm xylophone","Lively hand drum","Airy wind chimes","Gentle piano"};
        string[] images={"xyloGold","drumGold","chimes","pianoGold"};app.instruments=new InstrumentBank[4];
        for(int bank=0;bank<4;bank++)
        {
            var instrument=new InstrumentBank{name=names[bank],art=images[bank],notes=new AudioClip[5]};
            for(int key=0;key<5;key++)instrument.notes[key]=Clip($"Assets/Audio/Instruments/{bank}_{key}.wav");
            app.instruments[bank]=instrument;
        }
        app.calmTracks=new AudioClip[3];for(int i=0;i<3;i++)app.calmTracks[i]=Clip($"Assets/Audio/Calm/{i}.wav");
        app.wordPrompts=new AudioClip[4];for(int i=0;i<4;i++)app.wordPrompts[i]=Clip($"Assets/Audio/Words/{i}.wav");
        app.voices=new AudioSource[24];for(int i=0;i<app.voices.Length;i++)app.voices[i]=Source(root);
        app.backgroundVoice=Source(root);app.speechVoice=Source(root);
        var canvasObject=new GameObject("Canvas",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
        canvasObject.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
        var scaler=canvasObject.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1194,834);scaler.matchWidthOrHeight=.5f;
        var safe=OfflineUI.Rect(canvasObject.transform,"SafeArea",0,0,1194,834);safe.anchorMin=Vector2.zero;safe.anchorMax=Vector2.one;safe.offsetMin=safe.offsetMax=Vector2.zero;safe.gameObject.AddComponent<SafeAreaFit>();
        var frame=OfflineUI.Rect(safe,"DesignFrame",0,0,1194,834);frame.anchorMin=frame.anchorMax=frame.pivot=new Vector2(.5f,.5f);frame.anchoredPosition=Vector2.zero;frame.gameObject.AddComponent<DesignFrameFit>();app.frame=frame;
        new GameObject("EventSystem",typeof(EventSystem),typeof(StandaloneInputModule));
        app.Preview();
        PlayerSettings.productName="Yinya Music";PlayerSettings.defaultInterfaceOrientation=UIOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToPortrait=false;PlayerSettings.allowedAutorotateToPortraitUpsideDown=false;
        EditorSceneManager.SaveScene(scene,ScenePath);
        EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(ScenePath,true),new EditorBuildSettingsScene(YinyaSceneBuilder.ScenePath,false)};
        AssetDatabase.SaveAssets();Debug.Log("Yinya offline app created: "+ScenePath);
    }
    private static AudioClip Clip(string path)
    {var clip=AssetDatabase.LoadAssetAtPath<AudioClip>(path);if(clip==null)throw new InvalidOperationException("Missing audio: "+path);return clip;}
    private static AudioSource Source(GameObject p)
    {var source=p.AddComponent<AudioSource>();source.playOnAwake=false;source.spatialBlend=0;return source;}
    private static void ImportArt()
    {
        string capsule="Assets/Art/Generated/Capsule.png";
        if(!File.Exists(capsule))File.Copy("Assets/Art/Generated/Circle.png",capsule);
        AssetDatabase.Refresh();
        var pill=(TextureImporter)AssetImporter.GetAtPath(capsule);pill.textureType=TextureImporterType.Sprite;pill.spriteBorder=new Vector4(31,31,31,31);pill.alphaIsTransparency=true;pill.mipmapEnabled=false;pill.SaveAndReimport();
        foreach(string file in Directory.GetFiles("Assets/Art/Offline","*.png"))
        {
            var importer=(TextureImporter)AssetImporter.GetAtPath(file);importer.textureType=TextureImporterType.Sprite;
            importer.alphaIsTransparency=true;importer.mipmapEnabled=false;importer.maxTextureSize=2048;importer.textureCompression=TextureImporterCompression.Uncompressed;importer.SaveAndReimport();
        }
    }
}
