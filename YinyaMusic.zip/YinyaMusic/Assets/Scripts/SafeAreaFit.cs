using UnityEngine;

namespace Yinya
{
    [RequireComponent(typeof(RectTransform))]
    public sealed class SafeAreaFit : MonoBehaviour
    {
        private Rect previous;
        private Vector2Int previousSize;
        private void Update()
        {
            Rect safe = Screen.safeArea;
            var size = new Vector2Int(Screen.width, Screen.height);
            if (safe == previous && size == previousSize) return;
            previous = safe; previousSize = size;
            var rect = (RectTransform)transform;
            rect.anchorMin = new Vector2(safe.xMin / size.x, safe.yMin / size.y);
            rect.anchorMax = new Vector2(safe.xMax / size.x, safe.yMax / size.y);
            rect.offsetMin = rect.offsetMax = Vector2.zero;
        }
    }
}
