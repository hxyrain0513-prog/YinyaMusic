using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using static Yinya.OfflineUI;

namespace Yinya
{
    [Serializable] public class NamedArt { public string name; public Sprite sprite; }
    [Serializable] public class InstrumentBank { public string name,art; public AudioClip[] notes; }
    public sealed partial class OfflineApp : MonoBehaviour
    {
        public RectTransform frame;
        public ToyInput input;
        public TMP_FontAsset regularFont,boldFont;
        public Sprite roundSprite,circleSprite,pillSprite;
        public NamedArt[] assets;
        public InstrumentBank[] instruments;
        public AudioClip[] calmTracks,wordPrompts;
        public AudioSource[] voices;
        public AudioSource backgroundVoice,speechVoice;
        public string ScreenId {get;private set;}="home";
        public OfflineStore Store {get;private set;}
        public int AudioTriggers {get;private set;}
        public bool Recording {get;private set;}
        public string GamePhase {get;private set;}="ready";
        private bool initialized;
        private int voiceCursor,listPage,period=7,selectedTrack,wordIndex,roundIndex;
        private float[] voiceTimes;
        private string chosenMood="",creationMood="",query="",status="";
        private bool favoritesOnly,trackPaused,repeat;
        private Creation draft,selectedCreation;
        private GameSession selectedSession;
        private TMP_Text liveNote,liveStatus,liveProgress,playLabel,recordLabel;
        private TMP_InputField titleField;
        private Button wordConfirm;
        private Slider progress;
        private RectTransform hero;
        private double recordStart,replayStart,replayOffset,wordReadyAt,timerEnd;
        private int replayIndex;
        private double preferencesSaveAt;
        private bool replaying,replayPaused;
        private bool awaitingAfterMood;
        private readonly List<PlayedNote> recorded=new List<PlayedNote>();
        private readonly string[] noteNames={"Do","Re","Mi","So","La"};
        private readonly string[] moodNames={"Happy","Calm","Sad","Upset"};
        private readonly string[] moodArts={"happy","calmFace","sad","upset"};
        private readonly string[] trackNames={"A little forest breeze","The moon says goodnight","Rain by the window"};
        private readonly string[] trackArts={"breeze","moon","rain"};
        private readonly string[] words={"Hello","Water","Mama","Bye bye"};

        private void Start()=>Initialize();
        public void Initialize()
        {
            if(initialized)return;
            initialized=true;Store=new OfflineStore();voiceTimes=new float[voices.Length];
            input.KeyChanged+=OnKey;
#if UNITY_WEBGL && !UNITY_EDITOR
            BrowserPlatform.Install();
#endif
            Go("home");
            if(!string.IsNullOrEmpty(Store.Error))Notice("Local records",Store.Error);
        }
        public void Preview()
        {
            Store=new OfflineStore();voiceTimes=new float[voices.Length];
            Render();
        }
        private void OnDestroy(){if(input!=null)input.KeyChanged-=OnKey;}
        private void OnApplicationPause(bool paused){if(paused)Suspend();}
        private void OnApplicationFocus(bool focused){if(!focused)Suspend();}
        private void OnApplicationQuit(){if(Store!=null)Store.Save();}
        private void Suspend()
        {
            if(!initialized)return;
            input.ReleaseAll();StopVoices();
            if(Recording)FinishRecording();
            if(replaying&&!replayPaused)ToggleReplay();
            if(backgroundVoice.isPlaying){backgroundVoice.Pause();trackPaused=true;}
            if(ScreenId=="rhythm"&&(GamePhase=="listen"||GamePhase=="count"||GamePhase=="respond")){GamePhase="paused";Render();}
            speechVoice.Stop();
            if(ScreenId=="word")wordReadyAt=0;
        }
        public Sprite Asset(string name)
        {
            var item=assets.FirstOrDefault(a=>a.name==name);
            if(item==null||item.sprite==null)throw new InvalidOperationException("Missing design asset: "+name);
            return item.sprite;
        }
        public void Go(string page)
        {
            if(Store==null){Initialize();return;}
            if(page!="mood"&&page!="history")awaitingAfterMood=false;
            if(preferencesSaveAt>0){preferencesSaveAt=0;Store.Save();}
            input.AcceptInput=false;input.ReleaseAll();StopVoices();speechVoice.Stop();
            if(Recording && page!="record") { CloseRecording(); }
            replaying=false;replayPaused=false;
            if(page!="calm"){backgroundVoice.Stop();timerEnd=0;}
            StopAllCoroutines();ScreenId=page;listPage=0;status="";Render();
        }
        public void Render()
        {
            Regular=regularFont;Bold=boldFont;Round=roundSprite;Circle=circleSprite;Pill=pillSprite;
            input.ReleaseAll();input.AcceptInput=false;Clear(frame);
            liveNote=liveStatus=liveProgress=playLabel=recordLabel=null;progress=null;hero=null;wordConfirm=null;
            switch(ScreenId)
            {
                case "home":HomeView();break;
                case "connect":ConnectView();break;
                case "device":DeviceView();break;
                case "profile":ProfileView();break;
                case "games":GamesView();break;
                case "rhythm":RhythmView();break;
                case "word":WordView();break;
                case "result":ResultView();break;
                case "mood":MoodView();break;
                case "history":HistoryView();break;
                case "calmlist":CalmListView();break;
                case "calm":CalmView();break;
                case "instruments":InstrumentView();break;
                case "play":case "record":PlayView();break;
                case "save":SaveView();break;
                case "library":LibraryView();break;
                case "detail":DetailView();break;
                case "care":CareView();break;
                case "records":RecordsView();break;
                default:HomeView();break;
            }
            input.AcceptInput=ScreenId=="play"||ScreenId=="record"||(ScreenId=="rhythm"&&GamePhase=="respond");
        }
        private RectTransform Page(string title,string subtitle,Color color,string back="home")
        {
            var page=Panel(frame,"Page_"+ScreenId,0,0,1194,834,color);
            Text(page,"Clock",DateTime.Now.ToString("HH:mm   ddd, MMM d",System.Globalization.CultureInfo.InvariantCulture),36,9,550,20,12);
            Text(page,"Mode","App-only mode",970,9,180,20,12,false,Muted,TextAlignmentOptions.Right);
            Icon(page,"Back",Asset("back"),36,49,()=>Go(back));
            Text(page,"Title",title,104,41,760,45,30,true);
            Text(page,"Subtitle",subtitle,104,86,760,25,15,false,Muted);
            string[] icons={"bluetooth","home","profile","settings"};string[] routes={"connect","home","profile","device"};
            for(int i=0;i<4;i++){string route=routes[i];Icon(page,"Nav_"+icons[i],Asset(icons[i]),930+i*60,51,()=>Go(route),color==Cream?ColorOf("E2EB97"):Color.white);}
            return page;
        }
        private void OnKey(int key,bool down,double time)
        {
            if(!down)return;
            PlayNote(key);
            if(liveNote!=null)liveNote.text=noteNames[key];
            if(Recording && recorded.Count<2000)recorded.Add(new PlayedNote(key,(float)(time-recordStart)));
            if(ScreenId=="rhythm"&&GamePhase=="respond")RhythmInput(key,time);
            if(hero!=null)hero.localScale=new Vector3(1.035f,1.035f,1);
        }
        public void PlayNote(int key,int instrument=-1)
        {
            int selected=instrument<0?Store.Data.instrument:instrument;
            if(key<0||key>4)return;
            int index=voiceCursor++%voices.Length;var voice=voices[index];
            voice.Stop();voice.clip=instruments[Mathf.Clamp(selected,0,3)].notes[key];voice.volume=Store.Data.volume;
            voiceTimes[index]=Time.unscaledTime;voice.Play();AudioTriggers++;
        }
        private void StopVoices(){foreach(var voice in voices)voice.Stop();}
        private void Update()
        {
            if(!initialized)return;
            if(preferencesSaveAt>0&&Time.realtimeSinceStartupAsDouble>=preferencesSaveAt){preferencesSaveAt=0;Persist();}
            for(int i=0;i<voices.Length;i++)if(voices[i].isPlaying)
            {
                float age=Time.unscaledTime-voiceTimes[i];
                voices[i].volume=Store.Data.volume*(Store.Data.gentle?Mathf.Clamp01(age/.06f):1)*Mathf.Exp(-age*(1-Store.Data.sustain)*1.8f);
            }
            if(hero!=null)hero.localScale=Vector3.Lerp(hero.localScale,Vector3.one,1-Mathf.Exp(-8*Time.unscaledDeltaTime));
            if(Recording)
            {
                if(recordLabel!=null)recordLabel.text="Recording · "+Duration((float)(AudioSettings.dspTime-recordStart))+" · "+recorded.Count+" notes";
                if(AudioSettings.dspTime-recordStart>=120||recorded.Count>=2000)FinishRecording();
            }
            if(replaying&&!replayPaused&&selectedCreation!=null)
            {
                double elapsed=AudioSettings.dspTime-replayStart+replayOffset;
                while(replayIndex<selectedCreation.notes.Count&&selectedCreation.notes[replayIndex].time<=elapsed)
                    PlayNote(selectedCreation.notes[replayIndex++].key,selectedCreation.instrument);
                if(liveProgress!=null)liveProgress.text=Duration((float)elapsed)+" / "+Duration(selectedCreation.duration);
                if(progress!=null)progress.SetValueWithoutNotify((float)elapsed/Mathf.Max(.1f,selectedCreation.duration));
                if(hero!=null)hero.localScale=Vector3.one*(1+.025f*Mathf.Sin((float)elapsed*5));
                if(elapsed>=selectedCreation.duration+.1f){replaying=false;if(playLabel!=null)playLabel.text="Play again";}
            }
            if(ScreenId=="calm")
            {
                backgroundVoice.volume=Store.Data.volume*.55f*(timerEnd>0?Mathf.Clamp01((float)(timerEnd-Time.realtimeSinceStartupAsDouble)/3):1);
                if(progress!=null)progress.SetValueWithoutNotify(backgroundVoice.clip==null?0:backgroundVoice.time/backgroundVoice.clip.length);
                if(liveProgress!=null)liveProgress.text=Duration(backgroundVoice.time)+" / "+Duration(backgroundVoice.clip.length)+(timerEnd>0?"  · Stop in "+Duration((float)(timerEnd-Time.realtimeSinceStartupAsDouble)):"");
                if(hero!=null)hero.localScale=Vector3.one*(1+.018f*Mathf.Sin(Time.unscaledTime*.9f));
                if(!backgroundVoice.isPlaying&&!trackPaused){trackPaused=true;if(playLabel!=null)playLabel.text="Play";}
                if(timerEnd>0&&Time.realtimeSinceStartupAsDouble>=timerEnd){backgroundVoice.Stop();trackPaused=true;timerEnd=0;if(playLabel!=null)playLabel.text="Play";}
            }
            if(ScreenId=="word"&&wordConfirm!=null)
            {
                wordConfirm.interactable=wordReadyAt>0&&AudioSettings.dspTime>=wordReadyAt;
                if(liveStatus!=null)liveStatus.text=wordConfirm.interactable?"Your turn · sing or say the word, then tell Yinya.":wordReadyAt>0?"Listen first. Take your time.":"Tap Listen to hear the word and melody.";
            }
            UpdateRhythm();
        }
        public void StartRecording()
        {
            if(draft!=null){Go("save");Notice("You have an unsaved melody","Save this melody before beginning another recording.");return;}
            Go("record");recorded.Clear();draft=null;recordStart=AudioSettings.dspTime;Recording=true;Render();
        }
        private void CloseRecording()
        {
            Recording=false;
            if(recorded.Count==0)return;
            draft=new Creation{id=OfflineStore.Id(),created=OfflineStore.Now(),title="My little melody",instrument=Store.Data.instrument,duration=Mathf.Max(1f,(float)(AudioSettings.dspTime-recordStart)),notes=new List<PlayedNote>(recorded)};
        }
        public void FinishRecording()
        {
            CloseRecording();Go(draft==null?"play":"save");
            if(draft==null)Notice("A sound is waiting","Play at least one note before saving your music.");
        }
        public void SaveDraft()
        {
            if(draft==null)return;
            string title=titleField==null?draft.title:titleField.text.Trim();
            if(string.IsNullOrWhiteSpace(title)){Notice("Give it a name","Please enter a name for this creation.");return;}
            draft.title=title;draft.mood=creationMood;Store.Data.creations.Add(draft);
            MoodEntry mood=null;
            if(!string.IsNullOrEmpty(creationMood)){mood=new MoodEntry{id=OfflineStore.Id(),created=OfflineStore.Now(),mood=creationMood,creationId=draft.id};Store.Data.moods.Add(mood);}
            if(!Store.Save()){Store.Data.creations.Remove(draft);if(mood!=null)Store.Data.moods.Remove(mood);Notice("Could not save",Store.Error);return;}
            selectedCreation=draft;draft=null;creationMood="";Go("detail");
        }
        public void BeginReplay(Creation creation)
        {
            if(creation==null||creation.notes.Count==0)return;
            selectedCreation=creation;replayIndex=0;replayOffset=0;replayStart=AudioSettings.dspTime+.08;replaying=true;replayPaused=false;
            if(playLabel!=null)playLabel.text="Pause";
        }
        public void ToggleReplay()
        {
            if(selectedCreation==null)return;
            if(!replaying){BeginReplay(selectedCreation);return;}
            if(!replayPaused){replayOffset+=AudioSettings.dspTime-replayStart;replayPaused=true;StopVoices();}
            else {replayStart=AudioSettings.dspTime;replayPaused=false;}
            if(playLabel!=null)playLabel.text=replayPaused?"Resume":"Pause";
        }
        private void SeekReplay(float value)
        {
            if(selectedCreation==null)return;
            replayOffset=value*selectedCreation.duration;replayStart=AudioSettings.dspTime;
            replayIndex=selectedCreation.notes.FindIndex(n=>n.time>=replayOffset);
            if(replayIndex<0)replayIndex=selectedCreation.notes.Count;StopVoices();
        }
        private void Persist(){if(!Store.Save())Notice("Local save",Store.Error);}
        private void QueuePreferences(){preferencesSaveAt=Time.realtimeSinceStartupAsDouble+.35;}
        private void Notice(string title,string body)
        {
            input.AcceptInput=false;input.ReleaseAll();
            var shade=Panel(frame,"Notice",0,0,1194,834,new Color(.2f,.23f,.28f,.4f));shade.GetComponent<Image>().raycastTarget=true;
            var box=Panel(shade,"Dialog",297,257,600,320,Paper);
            Text(box,"Title",title,30,24,540,50,28,true);Text(box,"Body",body,30,88,540,120,19);
            Button(box,"Dismiss","Back",30,232,540,56,()=>{shade.gameObject.SetActive(false);Destroy(shade.gameObject);input.AcceptInput=ScreenId=="play"||ScreenId=="record";},Brand,Color.white);
        }
        private static string Duration(float seconds){int t=Mathf.Max(0,Mathf.FloorToInt(seconds));return (t/60).ToString("00")+":"+(t%60).ToString("00");}
        private string DateLabel(string iso)=>OfflineStore.Date(iso).ToString("MMM d · HH:mm",System.Globalization.CultureInfo.InvariantCulture);
        private bool InPeriod(string iso)=>period==0||OfflineStore.Date(iso)>=DateTime.Now.AddDays(-period);
        private static string CountLabel(int count,string noun)=>count+" "+noun+(count==1?"":"s");
    }
}
