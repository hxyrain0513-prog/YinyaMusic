using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Yinya
{
    public sealed class YinyaApp : MonoBehaviour
    {
        public GameObject homePage, freePage, popup;
        public ToyInput input;
        public MusicAudio audioEngine;
        public TMP_Text popupTitle, popupBody, noteLabel, countLabel, clockHome, clockFree;
        public GameObject volumeControls;
        public Slider volumeSlider;
        public string CurrentPage { get; private set; } = "home";
        public int TapCount { get; private set; }
        private readonly string[] names = { "Do", "Re", "Mi", "So", "La" };
        private int lastMinute = -1;

        private void OnEnable()
        {
            input.KeyChanged += OnKey;
            volumeSlider.onValueChanged.AddListener(audioEngine.SetVolume);
        }
        private void OnDisable()
        {
            input.KeyChanged -= OnKey;
            volumeSlider.onValueChanged.RemoveListener(audioEngine.SetVolume);
        }
        private void Start() { ShowHome(); }
        public void ShowHome() => Show(false);
        public void ShowFreePlay() => Show(true);
        private void Show(bool free)
        {
            input.AcceptInput = false;
            input.ReleaseAll();
            audioEngine.StopAll();
            popup.SetActive(false);
            homePage.SetActive(!free);
            freePage.SetActive(free);
            CurrentPage = free ? "freeplay" : "home";
            input.AcceptInput = free;
        }
        private void OnKey(int key, bool down, double time)
        {
            if (!down) return;
            TapCount++;
            noteLabel.text = names[key];
            countLabel.text = TapCount == 1 ? "1 little sound made" : TapCount + " little sounds made";
        }
        private void Update()
        {
            var now = System.DateTime.Now;
            if (lastMinute == now.Minute) return;
            lastMinute = now.Minute;
            string text = now.ToString("HH:mm   ddd, MMM d", System.Globalization.CultureInfo.InvariantCulture);
            clockHome.text = text; clockFree.text = text;
        }
        public void ShowNotice(string topic)
        {
            input.AcceptInput = false; input.ReleaseAll(); audioEngine.StopAll();
            popupTitle.text = topic;
            bool settings = topic == "Sound settings";
            volumeControls.SetActive(settings);
            popupBody.text = settings ? "Find a comfortable volume for your music." :
                topic == "Connect your toy" ? "Touch play is ready.\nThe Arduino / HM-10 connection will be added in a later stage." :
                topic == "Music games" ? "Rhythm and word games are coming next.\nFor now, explore five sounds in Free creation." :
                topic == "Emotional music" ? "Mood choices and soothing music are coming next." :
                topic == "Change instrument" ? "Warm xylophone is available in this prototype.\nMore instruments will be added later." :
                topic == "Record my music" ? "Recording and saving creations are coming next.\nYou can already play all five notes." :
                topic == "My music" ? "No saved creations yet.\nSaving and playback will be added in a later stage." :
                "Your companion profile will be available in a later stage.";
            popup.SetActive(true);
        }
        public void ClosePopup() { popup.SetActive(false); input.AcceptInput = CurrentPage == "freeplay"; }
    }
}
