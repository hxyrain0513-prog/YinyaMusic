using UnityEngine;

namespace Yinya
{
    [ExecuteAlways]
    public sealed class DesignFrameFit : MonoBehaviour
    {
        private void LateUpdate()
        {
            var parent=transform.parent as RectTransform;
            if(parent==null)return;
            float factor=Mathf.Min(parent.rect.width/1194f,parent.rect.height/834f);
            transform.localScale=new Vector3(factor,factor,1);
        }
    }
}
