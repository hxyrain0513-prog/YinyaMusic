using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Yinya
{
    public static class OfflineUI
    {
        public static TMP_FontAsset Regular,Bold;
        public static Sprite Round,Circle,Pill;
        public static Color Ink=ColorOf("343A48"),Muted=ColorOf("68717C"),Brand=ColorOf("46566A"),Lime=ColorOf("C8D74E"),Cream=ColorOf("FCFFE0"),Paper=ColorOf("FFF6E4"),Gold=ColorOf("F0D585"),Orange=ColorOf("F9A561");
        public static Color ColorOf(string hex){ColorUtility.TryParseHtmlString("#"+hex,out var c);return c;}
        public static RectTransform Rect(Transform p,string name,float x,float y,float w,float h)
        {var r=new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();r.SetParent(p,false);r.anchorMin=r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-y);r.sizeDelta=new Vector2(w,h);return r;}
        public static RectTransform Panel(Transform p,string name,float x,float y,float w,float h,Color color)
        {var r=Rect(p,name,x,y,w,h);var image=r.gameObject.AddComponent<Image>();image.sprite=Round;image.type=Image.Type.Sliced;image.color=color;image.raycastTarget=false;return r;}
        public static TMP_Text Text(Transform p,string name,string text,float x,float y,float w,float h,int size=18,bool bold=false,Color? color=null,TextAlignmentOptions align=TextAlignmentOptions.TopLeft)
        {var r=Rect(p,name,x,y,w,h);var t=r.gameObject.AddComponent<TextMeshProUGUI>();t.font=bold?Bold:Regular;t.text=text;t.fontSize=size;t.color=color??Ink;t.alignment=align;t.raycastTarget=false;t.enableWordWrapping=true;return t;}
        public static Image Art(Transform p,string name,Sprite sprite,float x,float y,float w,float h)
        {var r=Rect(p,name,x,y,w,h);var image=r.gameObject.AddComponent<Image>();image.sprite=sprite;image.preserveAspect=true;image.raycastTarget=false;return image;}
        public static Button Button(Transform p,string name,string text,float x,float y,float w,float h,Action action,Color? bg=null,Color? fg=null)
        {var r=Panel(p,name,x,y,w,h,bg??Color.white);var image=r.GetComponent<Image>();
         image.sprite=h<=64&&Pill!=null?Pill:Round;image.raycastTarget=true;var button=r.gameObject.AddComponent<Button>();button.targetGraphic=image;button.onClick.AddListener(()=>action());Text(r,"Label",text,10,0,w-20,h,18,false,fg??Brand,TextAlignmentOptions.Center);return button;}
        public static Button Icon(Transform p,string name,Sprite sprite,float x,float y,Action action,Color? bg=null)
        {var b=Button(p,name,"",x,y,48,48,action,bg);b.image.sprite=Circle;b.image.type=Image.Type.Simple;float size=sprite.name=="settings"?17:22;Art(b.transform,"Icon",sprite,(48-size)/2,(48-size)/2,size,size);return b;}
        public static Slider Slider(Transform p,string name,float x,float y,float w,float value,Action<float> changed)
        {
            var root=Rect(p,name,x,y,w,36);var track=Panel(root,"Track",0,12,w,12,ColorOf("E7EABF"));track.GetComponent<Image>().raycastTarget=true;
            var area=Rect(root,"FillArea",0,12,w,12);var fill=Panel(area,"Fill",0,0,w,12,Lime);
            fill.anchorMin=Vector2.zero;fill.anchorMax=Vector2.one;fill.offsetMin=fill.offsetMax=Vector2.zero;
            var handles=Rect(root,"HandleArea",12,6,w-24,24);var handle=Panel(handles,"Handle",0,0,24,0,Brand);handle.pivot=new Vector2(.5f,.5f);handle.GetComponent<Image>().sprite=Circle;handle.GetComponent<Image>().type=Image.Type.Simple;
            var slider=root.gameObject.AddComponent<Slider>();slider.fillRect=fill;slider.handleRect=handle;slider.targetGraphic=handle.GetComponent<Image>();
            slider.SetValueWithoutNotify(value);slider.onValueChanged.AddListener(v=>changed(v));return slider;
        }
        public static TMP_InputField Input(Transform p,string name,string value,string hint,float x,float y,float w)
        {
            var root=Panel(p,name,x,y,w,56,Color.white);root.GetComponent<Image>().raycastTarget=true;
            var viewport=Rect(root,"Viewport",14,4,w-28,48);viewport.gameObject.AddComponent<RectMask2D>();
            var text=Text(viewport,"Text",value,0,0,w-28,48,18,false,Ink,TextAlignmentOptions.MidlineLeft);
            var placeholder=Text(viewport,"Placeholder",hint,0,0,w-28,48,18,false,Muted,TextAlignmentOptions.MidlineLeft);
            var input=root.gameObject.AddComponent<TMP_InputField>();input.textViewport=viewport;input.textComponent=(TextMeshProUGUI)text;input.placeholder=placeholder;
            input.characterLimit=60;input.text=value;
#if UNITY_WEBGL && !UNITY_EDITOR
            input.readOnly=true;root.gameObject.AddComponent<BrowserInputField>().field=input;
#endif
            return input;
        }
        public static void Clear(Transform parent)
        {for(int i=parent.childCount-1;i>=0;i--){var child=parent.GetChild(i).gameObject;child.SetActive(false);child.name="Retired";if(Application.isPlaying)UnityEngine.Object.Destroy(child);else UnityEngine.Object.DestroyImmediate(child);}}
        public static Image CroppedArt(Transform parent,string name,Sprite sprite,float x,float y,float width,float height,Vector4 imageRect)
        {
            var mask=Rect(parent,name,x,y,width,height);mask.gameObject.AddComponent<RectMask2D>();
            var image=Art(mask,"Source",sprite,imageRect.x*width,imageRect.y*height,imageRect.z*width,imageRect.w*height);
            image.preserveAspect=false;return image;
        }
    }
}
