using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
#if UNITY_WEBGL && !UNITY_EDITOR
using System.Runtime.InteropServices;
#endif

namespace Yinya
{
    [Serializable] public class PlayedNote { public int key; public float time; public PlayedNote(int key,float time){this.key=key;this.time=time;} }
    [Serializable] public class Creation
    {
        public string id,title,created,mood="",kind="music";
        public int instrument;
        public float duration;
        public bool favorite;
        public List<PlayedNote> notes=new List<PlayedNote>();
    }
    [Serializable] public class MoodEntry { public string id,created,mood,source="child-choice",creationId=""; }
    [Serializable] public class GameSession
    {
        public string id,created,game,level="1",moodBefore="",moodAfter="";
        public bool hasScore;
        public int score,rhythm,melody,completion,rounds;
        public float duration;
    }
    [Serializable] public class OfflineData
    {
        public int version=1,instrument;
        public float volume=.5f,sustain=.6f;
        public bool gentle=true;
        public List<int> favoriteTracks=new List<int>();
        public List<Creation> creations=new List<Creation>();
        public List<MoodEntry> moods=new List<MoodEntry>();
        public List<GameSession> games=new List<GameSession>();
    }
    public sealed class OfflineStore
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")] private static extern string YinyaStorageRead(int backup);
        [DllImport("__Internal")] private static extern int YinyaStorageWrite(string data);
#endif
        public OfflineData Data {get;private set;}
        public string Error {get;private set;}="";
        public string FilePath {get;}
        public OfflineStore(string path=null)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            FilePath="browser-local-storage";Data=new OfflineData();
            try
            {
                string data=YinyaStorageRead(0);
                if(data=="__UNAVAILABLE__")Error="Browser storage is unavailable. Your music can be played, but may not be saved. Use a normal Safari tab and allow site storage.";
                else if(!string.IsNullOrEmpty(data))Data=Decode(data);
            }
            catch
            {
                try{Data=Decode(YinyaStorageRead(1));Error="Recovered the previous browser backup.";}
                catch{Data=new OfflineData();Error="Saved browser records could not be read.";}
            }
#else
            FilePath=path??Path.Combine(Application.persistentDataPath,"yinya-offline-v1.json");
            Data=new OfflineData();
            if(!File.Exists(FilePath))return;
            try { Data=Read(FilePath); }
            catch(Exception error)
            {
                Error="The saved data could not be read. "+error.Message;
                try { Data=Read(FilePath+".bak");Error="Recovered the previous local backup."; }
                catch { Data=new OfflineData(); }
            }
#endif
            Data.instrument=Mathf.Clamp(Data.instrument,0,3);
            Data.volume=Mathf.Clamp01(Data.volume);Data.sustain=Mathf.Clamp01(Data.sustain);
        }
        private OfflineData Read(string path)
        {
            return Decode(File.ReadAllText(path));
        }
        private OfflineData Decode(string json)
        {
            var data=JsonUtility.FromJson<OfflineData>(json);
            if(data==null||data.version!=1||data.creations==null||data.moods==null||data.games==null||data.favoriteTracks==null)
                throw new InvalidDataException("Unknown or incomplete save format.");
            return data;
        }
        public bool Save()
        {
            try
            {
#if UNITY_WEBGL && !UNITY_EDITOR
                if(YinyaStorageWrite(JsonUtility.ToJson(Data))!=1)throw new IOException("Browser storage is full or unavailable. Export or free browser space before saving more music.");
#else
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                File.WriteAllText(FilePath+".tmp",JsonUtility.ToJson(Data,true));
                if(File.Exists(FilePath))File.Replace(FilePath+".tmp",FilePath,FilePath+".bak");
                else File.Move(FilePath+".tmp",FilePath);
#endif
                Error="";return true;
            }
            catch(Exception error){Error="Could not save locally: "+error.Message;Debug.LogWarning(Error);return false;}
        }
        public static string Id()=>Guid.NewGuid().ToString("N");
        public static string Now()=>DateTime.UtcNow.ToString("o");
        public static DateTime Date(string iso)=>DateTime.TryParse(iso,null,System.Globalization.DateTimeStyles.RoundtripKind,out var date)?date.ToLocalTime():DateTime.MinValue;
        public string LatestMood=>Data.moods.Count==0?"Not recorded":Data.moods[Data.moods.Count-1].mood;
    }
}
