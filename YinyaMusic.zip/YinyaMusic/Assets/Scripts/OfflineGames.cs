using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using static Yinya.OfflineUI;

namespace Yinya
{
    public sealed partial class OfflineApp
    {
        private double gameStart,responseStart;
        private int[] targetKeys;
        private bool[] matched;
        private float[] timingErrors;
        private int roundWrong,totalHits,totalTargets,totalWrong;
        private float totalTiming;
        private string beforeMood="";
        private GameSession result;
        public int CompletedRounds {get;private set;}

        public void StartRhythm()
        {
            Go("rhythm");roundIndex=0;CompletedRounds=0;totalHits=totalTargets=totalWrong=0;totalTiming=0;
            gameStart=AudioSettings.dspTime;beforeMood=Store.LatestMood;GamePhase="ready";PrepareRound();Render();
        }
        private void PrepareRound()
        {
            int[][] rounds={new[]{0,1,2},new[]{2,1,0},new[]{0,2,3,2},new[]{0,1,2,3,4}};
            targetKeys=rounds[Mathf.Clamp(roundIndex,0,3)];matched=new bool[targetKeys.Length];timingErrors=new float[targetKeys.Length];roundWrong=0;
        }
        public void Demonstrate()
        {
            if(ScreenId!="rhythm")return;
            StopAllCoroutines();input.AcceptInput=false;input.ReleaseAll();StopVoices();PrepareRound();GamePhase="listen";Render();StartCoroutine(DemoRound());
        }
        private IEnumerator DemoRound()
        {
            double start=AudioSettings.dspTime+.3;
            for(int i=0;i<targetKeys.Length;i++)
            {
                double due=start+i*.7;
                while(AudioSettings.dspTime<due)yield return null;
                PlayNote(targetKeys[i]);if(liveNote!=null)liveNote.text=noteNames[targetKeys[i]];
                if(hero!=null)hero.localScale=new Vector3(1.04f,1.04f,1);
            }
            while(AudioSettings.dspTime<start+targetKeys.Length*.7+.2)yield return null;
            GamePhase="count";responseStart=AudioSettings.dspTime+2.0;Render();
            while(AudioSettings.dspTime<responseStart){if(liveStatus!=null)liveStatus.text="Your turn in "+Mathf.CeilToInt((float)(responseStart-AudioSettings.dspTime));yield return null;}
            GamePhase="respond";Render();
        }
        private void RhythmInput(int key,double now)
        {
            float elapsed=(float)(now-responseStart);int nearest=-1;float best=.351f;
            for(int i=0;i<targetKeys.Length;i++)
            {
                float delta=Mathf.Abs(elapsed-i*.7f);
                if(!matched[i]&&delta<best){nearest=i;best=delta;}
            }
            if(nearest>=0&&targetKeys[nearest]==key)
            {matched[nearest]=true;timingErrors[nearest]=best;if(liveStatus!=null)liveStatus.text="We heard your sound!";}
            else {roundWrong++;if(liveStatus!=null)liveStatus.text="Keep listening · every try is welcome.";}
        }
        private void UpdateRhythm()
        {
            if(ScreenId!="rhythm"||GamePhase!="respond"||targetKeys==null)return;
            double elapsed=AudioSettings.dspTime-responseStart;
            if(liveProgress!=null)liveProgress.text="Round "+(roundIndex+1)+" / 4 · "+Array.FindAll(matched,m=>m).Length+" / "+targetKeys.Length+" sounds matched";
            if(elapsed>(targetKeys.Length-1)*.7+.55)FinishRound();
        }
        public void FinishRound()
        {
            if(GamePhase!="respond")return;
            for(int i=0;i<matched.Length;i++)if(matched[i]){totalHits++;totalTiming+=timingErrors[i];}
            totalTargets+=targetKeys.Length;totalWrong+=roundWrong;CompletedRounds++;GamePhase="feedback";input.AcceptInput=false;Render();
        }
        public void NextRound()
        {
            if(GamePhase!="feedback")return;
            if(roundIndex<3){roundIndex++;GamePhase="ready";PrepareRound();Render();}
            else FinishRhythm();
        }
        private void FinishRhythm()
        {
            int melody=Mathf.RoundToInt(100f*totalHits/Mathf.Max(1,totalTargets+totalWrong));
            int timing=totalHits==0?0:Mathf.RoundToInt(100*Mathf.Clamp01(1-totalTiming/totalHits/.35f));
            int complete=Mathf.RoundToInt(100f*totalHits/Mathf.Max(1,totalTargets));
            result=new GameSession{id=OfflineStore.Id(),created=OfflineStore.Now(),game="Rhythm play",hasScore=true,rhythm=timing,melody=melody,completion=complete,score=Mathf.RoundToInt((timing+melody+complete)/3f),rounds=CompletedRounds,duration=(float)(AudioSettings.dspTime-gameStart),moodBefore=beforeMood};
            Store.Data.games.Add(result);if(!Store.Save()){Store.Data.games.Remove(result);Notice("Could not save",Store.Error);return;}Go("result");
        }
        private void RhythmView()
        {
            var p=Page("Rhythm play","Round "+(roundIndex+1)+" / 4 · Listen, then take your turn",Orange,"games");
            var main=Panel(p,"Stage",28,133,1138,565,Color.white);
            var actor=Art(main,"Mascot",Asset("rhythm"),48,12,450,454);actor.preserveAspect=false;hero=actor.rectTransform;
            Text(main,"Heading",GamePhase=="ready"?"Listen first":GamePhase=="listen"?"Yinya's turn":GamePhase=="respond"?"Your turn to tap":GamePhase=="feedback"?"A little progress":GamePhase=="paused"?"Take your time":"Get ready",555,30,550,60,32,true);
            liveNote=Text(main,"Note",GamePhase=="respond"?"Follow the beat":"",555,105,550,60,36,true,Brand,TextAlignmentOptions.Center);
            string pattern=string.Join("  ·  ",Array.ConvertAll(targetKeys??new[]{0,1,2},k=>noteNames[k]));
            Text(main,"Pattern",pattern,555,190,550,58,26,true,Brand,TextAlignmentOptions.Center);
            liveStatus=Text(main,"State",GamePhase=="ready"?"Hear the melody. Then repeat the notes at the same pace.":GamePhase=="listen"?"Listen to the notes and their rhythm.":GamePhase=="respond"?"Tap the five keys below.":GamePhase=="feedback"?"Thank you for trying. Let's keep exploring.":"We can listen again whenever you're ready.",555,267,550,100,21,false,Muted);
            liveProgress=Text(main,"Progress","Round "+(roundIndex+1)+" / 4",555,388,550,36,18,false,Muted);
            if(GamePhase=="ready"||GamePhase=="paused")Button(main,"ListenPattern","Listen to Yinya",555,456,550,56,Demonstrate,Orange);
            if(GamePhase=="feedback")Button(main,"NextRound",roundIndex==3?"See my little progress":"Next round",555,456,550,56,NextRound,Orange);
            Keys(p,52,722,760,88);
            if(GamePhase!="feedback")Button(p,"ReplayPattern","Listen again",840,738,302,56,Demonstrate);
        }
        public void StartWords()
        {
            Go("word");wordIndex=0;wordReadyAt=0;CompletedRounds=0;gameStart=AudioSettings.dspTime;beforeMood=Store.LatestMood;Render();
        }
        public void PlayWord()
        {
            if(ScreenId!="word")return;
            speechVoice.Stop();PlayNote(wordIndex%5);speechVoice.clip=wordPrompts[wordIndex];speechVoice.volume=Store.Data.volume;speechVoice.PlayDelayed(.65f);
            wordReadyAt=AudioSettings.dspTime+.65+speechVoice.clip.length+.4;
            if(wordConfirm!=null)wordConfirm.interactable=false;
            if(hero!=null)hero.localScale=new Vector3(1.04f,1.04f,1);
        }
        public void ConfirmWord()
        {
            if(ScreenId!="word"||wordReadyAt<=0||AudioSettings.dspTime<wordReadyAt)return;
            CompletedRounds++;speechVoice.Stop();
            if(wordIndex<3){wordIndex++;wordReadyAt=0;Render();}
            else
            {
                result=new GameSession{id=OfflineStore.Id(),created=OfflineStore.Now(),game="Word play",hasScore=false,completion=100,rounds=4,duration=(float)(AudioSettings.dspTime-gameStart),moodBefore=beforeMood};
                Store.Data.games.Add(result);if(!Store.Save()){Store.Data.games.Remove(result);Notice("Could not save",Store.Error);return;}Go("result");
            }
        }
        private void WordView()
        {
            var p=Page("Word play","Listen, then sing the little words",Orange,"games");
            var body=Panel(p,"Stage",28,133,1138,565,Color.white);
            hero=CroppedArt(body,"Mascot",Asset("word"),48,12,450,510,new Vector4(-.5f,0,2,1)).rectTransform;
            Text(body,"Round","Word "+(wordIndex+1)+" / 4",555,30,550,35,20,false,Muted);
            Text(body,"Word",words[wordIndex],555,90,550,100,62,true,Brand,TextAlignmentOptions.Center);
            liveStatus=Text(body,"Instruction","Tap Listen to hear the word and melody.",555,210,550,100,22,false,Muted);
            Button(body,"ListenWord","Listen again",555,330,550,56,PlayWord,Orange);
            wordConfirm=Button(body,"ConfirmWord","I sang / said it",555,410,550,56,ConfirmWord,Brand,Color.white);
            wordConfirm.interactable=wordReadyAt>0&&AudioSettings.dspTime>=wordReadyAt;
            Text(p,"Assessment","You choose when you have finished. This activity does not score pronunciation.",52,734,1090,66,19,false,Brand);
        }
        private void ResultView()
        {
            var p=Page("A little progress","Thank you for exploring with Yinya",Orange,"games");
            var art=Panel(p,"Thanks",52,145,500,565,Paper);Art(art,"Companions",Asset("companions"),24,16,452,370);
            Text(art,"Message","We heard your sound",24,408,452,80,32,true);
            var data=Panel(p,"Result",580,145,562,565,Paper);
            if(result==null){Text(data,"Empty","Complete a game to see your progress.",24,24,514,100,26);return;}
            Text(data,"Title",result.game,24,24,514,44,28,true);
            Text(data,"Score",result.hasScore?result.score+" / 100":"4 little words explored",24,94,514,80,42,true,Brand);
            Text(data,"Details",result.hasScore?"Rhythm accuracy  "+result.rhythm+"\nMelody matching  "+result.melody+"\nTask completion  "+result.completion:"Completion selected by you.\nPronunciation was not assessed.",24,200,514,130,22);
            Text(data,"Duration","Time together · "+Duration(result.duration),24,350,514,40,18,false,Muted);
            Button(data,"PlayAgain","Explore another game",24,420,514,56,()=>Go("games"),Brand,Color.white);
            Button(data,"AfterMood","How do you feel now?",24,492,514,48,()=>{awaitingAfterMood=true;chosenMood="";Go("mood");});
        }
    }
}
