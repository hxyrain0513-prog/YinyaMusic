using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using UnityEngine;

namespace Yinya
{
    public sealed class ToyInput : MonoBehaviour
    {
        public event Action<int, bool, double> KeyChanged;
        public bool AcceptInput { get; set; }
        private readonly HashSet<string>[] owners = {
            new HashSet<string>(), new HashSet<string>(), new HashSet<string>(),
            new HashSet<string>(), new HashSet<string>() };
        private readonly ConcurrentQueue<string> hardwareLines = new ConcurrentQueue<string>();

        // Thread-safe adapter seam: pass complete newline-delimited K,1,1,42 messages here.
        // A future BLE transport must buffer fragmented packets before calling this method.
        public void EnqueueHardwareLine(string line) => hardwareLines.Enqueue(line);

        public void SetKey(int key, bool down, string source)
        {
            if (key < 0 || key >= owners.Length || string.IsNullOrEmpty(source)) return;
            if (down && !AcceptInput) return;
            bool before = owners[key].Count > 0;
            if (down) owners[key].Add(source); else owners[key].Remove(source);
            bool after = owners[key].Count > 0;
            if (before != after) KeyChanged?.Invoke(key, after, AudioSettings.dspTime);
        }

        public void ReleaseSource(string source)
        {
            for (int i = 0; i < 5; i++) SetKey(i, false, source);
        }

        public void ReleaseAll()
        {
            for (int i = 0; i < 5; i++)
            {
                if (owners[i].Count == 0) continue;
                owners[i].Clear();
                KeyChanged?.Invoke(i, false, AudioSettings.dspTime);
            }
        }

        private void Update()
        {
            int budget = 64;
            while (budget-- > 0 && hardwareLines.TryDequeue(out string line))
            {
                var fields = line.Trim().Split(',');
                if (fields.Length != 4 || fields[0] != "K" ||
                    !int.TryParse(fields[1], out int key) || key < 1 || key > 5 ||
                    (fields[2] != "0" && fields[2] != "1") ||
                    !uint.TryParse(fields[3], out _)) continue;
                SetKey(key - 1, fields[2] == "1", "hardware");
            }
            for (int i = 0; i < 5; i++)
            {
                var key = (KeyCode)((int)KeyCode.Alpha1 + i);
                if (Input.GetKeyDown(key)) SetKey(i, true, "keyboard");
                if (Input.GetKeyUp(key)) SetKey(i, false, "keyboard");
            }
        }
        private void OnApplicationFocus(bool focus) { if (!focus) ReleaseAll(); }
        private void OnApplicationPause(bool paused) { if (paused) ReleaseAll(); }
        private void OnDisable() => ReleaseAll();
    }
}
