using System;
using System.Linq;
using TMPro;
using UnityEngine;
using static Yinya.OfflineUI;

namespace Yinya
{
    public sealed partial class OfflineApp
    {
        private void CareTabs(Transform p,string active)
        {
            string[] names={"Overview","Game & mood","Creations"};string[] routes={"care","records","library"};
            for(int i=0;i<3;i++){string route=routes[i];Button(p,"CareTab_"+i,names[i],36+i*164,154,150,44,()=>Go(route),route==active?Lime:Color.white);}
            int[] days={7,30,0};for(int i=0;i<3;i++){int day=days[i];Button(p,"CarePeriod_"+day,day==0?"All time":day+" days",566+i*164,154,150,44,()=>{period=day;listPage=0;Render();},period==day?Lime:Color.white);}
        }
        private void CareView()
        {
            var p=Page("Yinya's little steps","Caregiver space / Growth & creations",Cream,"profile");CareTabs(p,"care");
            var games=Store.Data.games.Where(g=>InPeriod(g.created)).ToList();
            var scored=games.Where(g=>g.hasScore&&g.game=="Rhythm play"&&g.level=="1").OrderBy(g=>g.created).ToList();
            var moods=Store.Data.moods.Where(m=>InPeriod(m.created)).ToList();
            var creations=Store.Data.creations.Where(c=>InPeriod(c.created)).Reverse().ToList();
            Stat(p,"Average",scored.Count==0?"No score yet":Mathf.RoundToInt((float)scored.Average(g=>g.score))+" / 100","Rhythm play · Level 1",36,218,264);
            Stat(p,"Mood",moods.Count==0?"Not recorded":moods[moods.Count-1].mood,"Latest child-selected feeling",322,218,264);
            Stat(p,"Creations",CountLabel(creations.Count,"creation"),"Sounds worth keeping",608,218,264);
            Stat(p,"Days",CountLabel(games.Select(g=>OfflineStore.Date(g.created).Date).Concat(creations.Select(c=>OfflineStore.Date(c.created).Date)).Distinct().Count(),"day"),"With recorded music play",894,218,264);
            var plot=Panel(p,"ScoreChart",36,366,720,260,Color.white);
            Text(plot,"Title","A little better each time",20,16,680,32,22,true);
            Text(plot,"Caption","Real sessions · Rhythm play · Level 1 · scale 0–100",20,53,680,26,14,false,Muted);
            if(scored.Count==0)Text(plot,"Empty","Complete a rhythm game to start your chart.",48,120,624,80,23,false,Muted);
            else
            {
                var points=scored.Skip(Mathf.Max(0,scored.Count-10)).ToList();
                var first=OfflineStore.Date(points[0].created);var last=OfflineStore.Date(points[points.Count-1].created);
                var previous=Vector2.zero;
                for(int level=0;level<=100;level+=50){float y=128+(100-level)*.95f;Panel(plot,"Grid"+level,52,y,644,1,ColorOf("E7EABF"));Text(plot,"Axis"+level,level.ToString(),10,y-10,36,22,12,false,Muted);}
                for(int i=0;i<points.Count;i++)
                {
                    var session=points[i];double span=(last-first).TotalSeconds;
                    float x=points.Count==1?372:span<.001?52+644*i/(points.Count-1):52+(float)((OfflineStore.Date(session.created)-first).TotalSeconds/span)*644;
                    float y=128+(100-session.score)*.95f;
                    if(i>0)Line(plot,previous,new Vector2(x,y),Brand);
                    previous=new Vector2(x,y);
                    var button=Button(plot,"ScorePoint"+i,"",x-16,y-16,32,32,()=>{selectedSession=session;Go("records");},Lime);button.image.sprite=circleSprite;button.image.type=UnityEngine.UI.Image.Type.Simple;
                    Text(plot,"PointValue"+i,session.score.ToString(),x-25,y-36,50,22,13,true,Brand,TextAlignmentOptions.Center);
                    if(i==0||i==points.Count-1)Text(plot,"Date"+i,OfflineStore.Date(session.created).ToString(span<1?"HH:mm:ss.fff":span<60?"HH:mm:ss":"MM/dd HH:mm"),Mathf.Clamp(x-45,52,600),237,100,18,11,false,Muted);
                }
            }
            var timeline=Panel(p,"MoodTimeline",778,366,380,260,Color.white);
            Text(timeline,"Title","How Yinya felt",20,16,340,32,22,true);
            Text(timeline,"Caption","Selected by your child · no mood score",20,53,340,38,14,false,Muted);
            var recent=moods.Skip(Mathf.Max(0,moods.Count-4)).ToList();
            for(int i=0;i<recent.Count;i++){var m=recent[i];int index=Mathf.Max(0,Array.IndexOf(moodNames,m.mood));MoodIcon(timeline,index,20+i*86,104,66);Text(timeline,"Date"+i,OfflineStore.Date(m.created).ToString("MM/dd\nHH:mm"),20+i*86,181,66,48,12,false,Muted,TextAlignmentOptions.Center);}
            if(recent.Count==0)Text(timeline,"Empty","No feelings recorded yet.",20,120,340,60,21,false,Muted);
            var works=Panel(p,"Creations",36,650,1122,144,Color.white);Text(works,"Title","Their sounds, their stories",20,12,650,32,22,true);
            if(creations.Count==0)Text(works,"Empty","Record a melody in Free creation to keep a moment here.",20,65,1082,50,19,false,Muted);
            for(int i=0;i<Mathf.Min(3,creations.Count);i++)
            {var c=creations[i];var card=Button(works,"CareCreation"+i,"",20+i*362,53,346,72,()=>{selectedCreation=c;Go("detail");},Paper);Art(card.transform,"Art",Asset(instruments[c.instrument].art),4,4,88,64);Text(card.transform,"Name",c.title,102,8,232,30,18,true);Text(card.transform,"Date",DateLabel(c.created)+" · "+Duration(c.duration),102,42,232,25,13,false,Muted);}
        }
        private void RecordsView()
        {
            var p=Page("Game & mood history","Small moments of practice and expression",Cream,"care");CareTabs(p,"records");
            var games=Store.Data.games.Where(g=>InPeriod(g.created)).Reverse().ToList();
            if(selectedSession==null||!games.Contains(selectedSession))selectedSession=games.FirstOrDefault();
            var list=Panel(p,"Sessions",36,218,644,526,Color.white);
            Text(list,"Title","Recent music games",20,18,604,36,24,true);
            Text(list,"Caption","Scores compare the same game and difficulty.",20,62,604,36,16,false,Muted);
            if(games.Count==0)Text(list,"Empty","No completed games yet.\nPlay a round of Rhythm or Word play to begin.",24,145,596,150,26,false,Muted);
            for(int i=0;i<Mathf.Min(4,games.Count-listPage*4);i++)
            {
                var g=games[listPage*4+i];var row=Button(list,"Session_"+i,"",20,112+i*96,604,82,()=>{selectedSession=g;Render();},g==selectedSession?ColorOf("EFF3C2"):Paper);
                Text(row.transform,"Game",g.game+" · Level "+g.level,16,10,370,28,21,true);Text(row.transform,"Date",DateLabel(g.created)+" · "+Duration(g.duration),16,46,370,26,15,false,Muted);
                Text(row.transform,"Score",g.hasScore?g.score+" / 100":"Completed",402,20,186,40,22,true,Brand,TextAlignmentOptions.Center);
            }
            Pagination(p,games.Count,4,36,754);
            var detail=Panel(p,"SessionDetail",704,218,454,526,Color.white);
            if(selectedSession==null){Text(detail,"Empty","Choose a completed game to see its details.",24,50,406,120,24,false,Muted);return;}
            var s=selectedSession;Text(detail,"Title",s.game,24,20,406,45,28,true);
            Text(detail,"Date",DateLabel(s.created)+" · "+Duration(s.duration),24,76,406,32,16,false,Muted);
            Text(detail,"Score",s.hasScore?s.score+" / 100":"4 words explored",24,125,406,72,42,true,Brand);
            if(s.hasScore)
            {
                string[] labels={"Rhythm accuracy","Melody matching","Task completion"};int[] values={s.rhythm,s.melody,s.completion};
                for(int i=0;i<3;i++){Text(detail,"Dimension"+i,labels[i]+" · "+values[i]+" / 100",24,215+i*64,406,28,17);Panel(detail,"Track"+i,24,249+i*64,406,9,ColorOf("EAF0BC"));if(values[i]>0)Panel(detail,"Value"+i,24,249+i*64,406*values[i]/100f,9,Lime);}
            }
            else Text(detail,"SelfReport","Self-reported completion.\nPronunciation was not assessed.",24,215,406,100,22,false,Muted);
            Text(detail,"Mood","Before: "+(string.IsNullOrEmpty(s.moodBefore)?"Not recorded":s.moodBefore)+"\nAfter: "+(string.IsNullOrEmpty(s.moodAfter)?"Not recorded":s.moodAfter),24,432,406,68,17,false,Muted);
        }
        private void Line(Transform parent,Vector2 from,Vector2 to,Color color)
        {
            var delta=to-from;var line=Panel(parent,"ChartLine",from.x,from.y,delta.magnitude,3,color);
            line.pivot=new Vector2(0,.5f);line.anchoredPosition=new Vector2(from.x,-from.y);line.localRotation=Quaternion.Euler(0,0,-Mathf.Atan2(delta.y,delta.x)*Mathf.Rad2Deg);
        }
    }
}
