using UnityEngine;

namespace Yinya
{
    public sealed class MusicAudio : MonoBehaviour
    {
        public ToyInput input;
        public AudioClip[] notes;
        public AudioSource[] voices;
        public int PlayedCount { get; private set; }
        public float Volume { get; private set; } = .55f;
        private void OnEnable() => input.KeyChanged += OnKey;
        private void OnDisable() { input.KeyChanged -= OnKey; StopAll(); }
        private void OnKey(int key, bool down, double time)
        {
            if (!down || key >= notes.Length || notes[key] == null) return;
            var voice = voices[key];
            voice.clip = notes[key];
            voice.volume = Volume;
            voice.Play();
            PlayedCount++;
        }
        public void SetVolume(float value)
        {
            Volume = Mathf.Clamp01(value);
            foreach (var voice in voices) voice.volume = Volume;
        }
        public void StopAll() { if (voices != null) foreach (var voice in voices) if (voice != null) voice.Stop(); }
    }
}
