using System;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using static Yinya.OfflineUI;

namespace Yinya
{
    public sealed partial class OfflineApp
    {
        private void HomeView()
        {
            var p=Page("Yinya · A little music world","A melody for every feeling",Cream);
            p.GetComponent<Image>().color=Lime;Panel(p,"Surface",10,118,1174,706,Cream).SetAsFirstSibling();
            Panel(p,"HeaderSurface",10,10,1174,150,Cream).SetAsFirstSibling();
            var mark=Panel(p,"MusicMark",36,49,48,48,Lime);mark.GetComponent<Image>().sprite=circleSprite;mark.GetComponent<Image>().type=Image.Type.Simple;Art(mark,"MusicIcon",Asset("music"),13,13,22,22);
            string[] names={"Music games","Emotional music","Free creation"};string[] subs={"Listen, tap and take turns","Every feeling deserves to be heard","Tap freely and make your music"};
            string[] icons={"drum","forest","piano"};string[] actions={"games","mood","play"};string[] buttons={"Play music","Explore my feelings","Explore sounds"};
            for(int i=0;i<3;i++)
            {
                var card=Panel(p,"HomeCard_"+i,61+370*i,222,350,480,i==0?Orange:i==1?Lime:ColorOf("F3D558"));
                Art(card,"Illustration",Asset(icons[i]),i==0?-92:i==1?-1:-57,i==0?30:i==1?63:58,i==0?531:i==1?358:462,i==0?266:i==1?162:209);
                Text(card,"Heading",names[i],16,268,318,39,26,true,Color.white,TextAlignmentOptions.Center);
                Text(card,"Copy",subs[i],16,310,318,52,16,false,ColorOf("507660"),TextAlignmentOptions.Top);
                string route=actions[i];Button(card,"Enter_"+route,buttons[i],20,391,310,56,()=>Go(route),Color.white,i==0?Orange:i==1?ColorOf("C28958"):ColorOf("919F20"));
            }
        }
        private void ConnectView()
        {
            var p=Page("Connect your music toy","Bring the screen's sounds to your hands",Cream);
            var left=Panel(p,"ToyCard",52,145,580,544,ColorOf("EAF0BC"));
            Art(left,"Toy",Asset("toy"),80,36,420,310);
            Art(left,"ToyKeys",Asset("toyKeys"),130,214,320,144);
            CroppedArt(left,"ToyScreen",Asset("toyScreen"),166,68,250,142,new Vector4(-.3333f,-.0034f,1.6786f,1.5261f));
            Text(left,"Together","Screen and toy, playing together",24,370,530,70,28,true);
            Text(left,"AppOnly","All touch interactions are available without a toy.",24,466,530,52,18,false,Muted);
            var right=Panel(p,"Steps",660,145,482,544,Cream);
            Text(right,"Pill","First connection",16,16,450,30,18,true);
            Text(right,"Meet","Three little steps\nto meet Yinya",16,78,450,100,32,true);
            string[] steps={"1   Turn on the toy","2   Enable Bluetooth and allow access","3   Keep the toy near your iPad"};
            for(int i=0;i<3;i++)Text(right,"Step"+i,steps[i],16,205+i*64,450,48,18);
            Button(right,"SearchToy","Search for Yinya",16,406,450,56,()=>Notice("No toy connection in this build","This offline app does not scan for Bluetooth devices.\nUse Try without connecting to play all touch activities."),Lime);
            Button(right,"TryOffline","Try without connecting",16,478,450,50,()=>Go("home"));
        }
        private void DeviceView()
        {
            var p=Page("My music toy","Find a comfortable sound and start exploring",Cream);
            var card=Panel(p,"Device",52,145,454,570,ColorOf("EAF0BC"));
            Text(card,"Name","Yinya · App-only",24,24,406,45,28,true);
            Art(card,"Toy",Asset("toy"),46,90,362,270);
            Art(card,"ToyKeys",Asset("toyKeys"),100,245,260,130);
            Text(card,"Connection","No toy connected\nBattery: unavailable",24,390,406,80,20);
            Button(card,"Connect","Connection options",24,490,406,56,()=>Go("connect"));
            var settings=Panel(p,"Preferences",530,145,612,570,Paper);
            Text(settings,"Heading","Sound & feedback",28,24,556,42,28,true);
            Text(settings,"VolumeLabel","App volume",28,93,556,32,20);
            Slider(settings,"AppVolume",28,135,556,Store.Data.volume,v=>{Store.Data.volume=v;QueuePreferences();});
            Text(settings,"SustainLabel","Note sustain",28,202,556,32,20);
            Slider(settings,"Sustain",28,244,556,Store.Data.sustain,v=>{Store.Data.sustain=v;QueuePreferences();});
            Button(settings,"Gentle","Gentle mode: "+(Store.Data.gentle?"on":"off"),28,318,556,56,()=>{Store.Data.gentle=!Store.Data.gentle;Persist();Render();},Lime);
            Text(settings,"GentleCopy","A softer attack helps each sound begin gently.\nToy light controls become available with hardware.",28,392,556,70,18,false,Muted);
            Button(settings,"StartPlaying","Start playing",28,490,556,56,()=>Go("play"),Lime);
        }
        private void ProfileView()
        {
            var p=Page("My companion","Listen and grow together",Cream);
            var c=Panel(p,"Companion",52,145,350,570,ColorOf("EAF0BC"));
            Text(c,"Name","Yinya's\nmusic world",24,24,302,100,30,true);
            Text(c,"Space","Caregiver space",24,140,302,30,18,false,Muted);
            CroppedArt(c,"Companions",Asset("companions"),10,220,330,320,new Vector4(-.3554f,.0062f,1.7769f,1));
            Text(p,"Steps","This week's little steps",430,145,712,42,28,true);
            int days=Store.Data.games.Select(g=>OfflineStore.Date(g.created)).Concat(Store.Data.creations.Select(c=>OfflineStore.Date(c.created))).Where(d=>d>=DateTime.Now.AddDays(-7)).Select(d=>d.Date).Distinct().Count();
            Stat(p,"Days",CountLabel(days,"day"),"Music play",430,210,220);Stat(p,"Songs",CountLabel(Store.Data.creations.Count,"song"),"Creations saved",666,210,220);
            Stat(p,"Minutes",Mathf.RoundToInt((Store.Data.games.Sum(g=>g.duration)+Store.Data.creations.Sum(c=>c.duration))/60)+" min","Recorded play time",902,210,240);
            Button(p,"CaregiverHistory","Mood & music history",430,365,712,96,()=>Go("care"));
            Button(p,"SoundPreferences","Sound preferences",430,485,712,96,()=>Go("device"));
            var tip=Panel(p,"Tip",430,605,712,110,Color.white);Text(tip,"Title","A little tip for caregivers",24,18,660,32,22,true);
            Text(tip,"Copy","Allow time to respond. Follow your child's sound.",24,58,660,42,18,false,Muted);
        }
        private void GamesView()
        {
            var p=Page("Music games","Listen, respond and take your time",Orange);
            for(int i=0;i<2;i++)
            {
                var card=Panel(p,"GameCard_"+i,52+i*568,130,518,624,Color.white);
                Text(card,"Title",i==0?"Rhythm play":"Word play",24,24,470,45,30,true);
                Text(card,"Subtitle",i==0?"Tap back the rhythm you hear":"Sing familiar words with a melody",24,80,470,56,20);
                if(i==0)Art(card,"Mascot",Asset("rhythm"),72,140,374,378).preserveAspect=false;
                else CroppedArt(card,"Mascot",Asset("word"),72,140,374,378,new Vector4(-.3732f,-.0002f,1.7521f,1.0004f));
                int type=i;Button(card,i==0?"StartRhythm":"StartWord","Play with Yinya",24,542,470,56,()=>{if(type==0)StartRhythm();else StartWords();},Orange);
            }
        }
        private void PlayView()
        {
            var p=Page("Free creation","Every tap is a little creation",Gold);
            var card=Panel(p,"InstrumentCard",52,133,300,565,ColorOf("FFEEBD"));
            Text(card,"Current","Current sound",24,24,252,38,18,true);
            Art(card,"InstrumentArt",Asset(instruments[Store.Data.instrument].art),24,84,252,140);
            Text(card,"Instrument",instruments[Store.Data.instrument].name,24,244,252,76,27,true);
            Text(card,"Copy","Do · Re · Mi · So · La\nFive notes, endless possibilities.",24,328,252,70,16,false,Muted);
            Button(card,"ChangeInstrument","Change instrument",24,408,252,56,()=>{if(Recording)FinishRecording();else Go("instruments");});
            Button(card,"RecordMusic",Recording?"Finish recording":"Record my music",24,484,252,56,()=>{if(Recording)FinishRecording();else StartRecording();},Brand,Color.white);
            var stage=Panel(p,"Stage",380,133,762,565,Color.white);
            var art=Art(stage,"Mascot",Asset("freeMascot"),40,0,682,390);hero=art.rectTransform;
            liveNote=Text(stage,"Note","Touch a sound",24,365,714,40,24,true,Brand,TextAlignmentOptions.Center);
            Keys(stage,24,416,714,108);
            recordLabel=Text(p,"RecordingStatus",Recording?"Recording...":"Touch the keys · or use 1 2 3 4 5",380,713,762,30,17,false,Brand);
            Button(p,"MyMusic","My music",953,752,194,56,()=>Go("library"));
            if(draft!=null&&!Recording)Button(p,"ResumeDraft","Unsaved melody",52,752,300,56,()=>Go("save"));
        }
        private void Keys(Transform p,float x,float y,float width,float height)
        {
            Color[] colors={Orange,Lime,ColorOf("9EBCE0"),ColorOf("D5BDF9"),Gold};float w=(width-48)/5;
            for(int i=0;i<5;i++)
            {
                var key=Panel(p,"Key_"+i,x+i*(w+12),y,w,height,colors[i]);key.GetComponent<Image>().raycastTarget=true;
                key.gameObject.SetActive(false);var script=key.gameObject.AddComponent<PianoKey>();script.input=input;script.key=i;script.face=key.GetComponent<Image>();script.normal=colors[i];key.gameObject.SetActive(true);
                Text(key,"Name",noteNames[i],0,0,w,height-24,23,true,Ink,TextAlignmentOptions.Center);
                Text(key,"Number",(i+1).ToString(),0,height-30,w,24,13,false,Brand,TextAlignmentOptions.Center);
            }
        }
        private void InstrumentView()
        {
            var p=Page("Choose an instrument","Find a sound you like today",Gold,"play");
            var body=Panel(p,"Body",28,133,1138,612,Paper);
            for(int i=0;i<4;i++)
            {
                var c=Panel(body,"Instrument_"+i,24+(i%2)*350,24+(i/2)*272,330,250,i==Store.Data.instrument?ColorOf("EFF3C2"):ColorOf("FFEEBD"));
                Art(c,"Art",Asset(instruments[i].art),20,12,290,130);
                Text(c,"Name",instruments[i].name,20,151,290,46,23,true);
                int index=i;Button(c,"SelectInstrument_"+i,i==Store.Data.instrument?"In use · preview":"Tap to listen",20,198,290,40,()=>{Store.Data.instrument=index;PlayNote(2);Persist();Render();});
            }
            var detail=Panel(body,"Settings",732,24,382,522,ColorOf("FFEEBD"));
            Text(detail,"Name",instruments[Store.Data.instrument].name,24,24,334,65,25,true);
            Text(detail,"Heading","Make the sound your own",24,105,334,70,25,true);
            Text(detail,"VolumeLabel","Volume",24,198,334,30,18);Slider(detail,"Volume",24,238,334,Store.Data.volume,v=>{Store.Data.volume=v;QueuePreferences();});
            Text(detail,"SustainLabel","Sustain",24,300,334,30,18);Slider(detail,"Sustain",24,340,334,Store.Data.sustain,v=>{Store.Data.sustain=v;QueuePreferences();});
            Button(detail,"UseInstrument","Use this sound",24,438,334,56,()=>Go("play"),Gold);
        }
        private void MoodView()
        {
            var p=Page("Emotional music","Every feeling deserves to be heard",Lime);
            var body=Panel(p,"Main",28,118,1138,612,Color.white);
            Text(body,"Heading","How do you feel right now?",24,42,680,48,30,true);
            MoodChoices(body,24,125,chosenMood,m=>{chosenMood=m;Render();});
            body.gameObject.AddComponent<RectMask2D>();var mascot=Art(body,"Mascot",Asset("moodMascot"),660,12,450,600);mascot.preserveAspect=false;hero=mascot.rectTransform;
            Button(body,"SaveFeeling",string.IsNullOrEmpty(chosenMood)?"Choose a feeling above":"Save this feeling · "+chosenMood,24,364,620,56,SaveMood,Lime);
            Button(body,"ExpressWithSound","Express it with sound",24,438,620,56,()=>{if(string.IsNullOrEmpty(chosenMood)){Notice("Choose a feeling","Choose a feeling first, or return home for free play.");return;}SaveMoodAndPlay();},Paper);
            Button(body,"MoodHistory","Mood history",24,518,620,56,()=>Go("history"),Lime);
            EmotionNav(p);
        }
        private void MoodChoices(Transform p,float x,float y,string selected,Action<string> changed,float scale=1)
        {
            for(int i=0;i<4;i++)
            {
                string mood=moodNames[i];var b=Button(p,"Mood_"+mood,"",x+i*164*scale,y,148*scale,194*scale,()=>changed(mood),mood==selected?Paper:Color.white);
                MoodIcon(b.transform,i,18*scale,14*scale,112*scale);
                Text(b.transform,"MoodName",mood,0,132*scale,148*scale,30*scale,Mathf.RoundToInt(18*scale),true,Ink,TextAlignmentOptions.Center);
                if(selected==mood)Text(b.transform,"Selected","Selected",0,165*scale,148*scale,22*scale,Mathf.RoundToInt(13*scale),false,Brand,TextAlignmentOptions.Center);
            }
        }
        private void SaveMood()
        {
            if(string.IsNullOrEmpty(chosenMood)){Notice("Every feeling is welcome","Tap one of the four feelings before saving.");return;}
            Store.Data.moods.Add(new MoodEntry{id=OfflineStore.Id(),created=OfflineStore.Now(),mood=chosenMood});
            string previousAfter=result==null?"":result.moodAfter;
            if(awaitingAfterMood&&result!=null)result.moodAfter=chosenMood;
            if(!Store.Save()){Store.Data.moods.RemoveAt(Store.Data.moods.Count-1);if(result!=null)result.moodAfter=previousAfter;Notice("Could not save",Store.Error);return;}
            awaitingAfterMood=false;
            Go("history");
        }
        private void SaveMoodAndPlay(){SaveMood();if(ScreenId=="history")Go("play");}
        private void EmotionNav(Transform p)
        {Button(p,"MyFeelings","My feelings",628,752,245,52,()=>Go("mood"),Paper);Button(p,"SoothingMusic","Soothing music",891,752,251,52,()=>Go("calmlist"));}
        private void HistoryView()
        {
            var p=Page("Mood history","Revisit your little feelings",Lime,"mood");
            PeriodButtons(p);
            var entries=Store.Data.moods.Where(m=>InPeriod(m.created)).Reverse().ToList();
            var left=Panel(p,"Summary",52,210,350,510,Paper);
            Text(left,"Title","Feelings have no scores",24,24,302,76,27,true);
            for(int i=0;i<4;i++){Art(left,"Face"+i,Asset(moodArts[i]),24,130+i*76,52,52);Text(left,"Count"+i,moodNames[i]+" · "+entries.Count(e=>e.mood==moodNames[i]),94,142+i*76,232,40,20);}
            var right=Panel(p,"History",426,210,716,510,Color.white);
            if(entries.Count==0)Text(right,"Empty","No feelings recorded yet.\nChoose a feeling to begin your timeline.",28,60,660,140,25);
            for(int i=0;i<Mathf.Min(4,entries.Count-listPage*4);i++)
            {var e=entries[listPage*4+i];var row=Panel(right,"MoodRow"+i,20,20+i*104,676,92,Paper);int index=Array.IndexOf(moodNames,e.mood);MoodIcon(row,Mathf.Max(0,index),16,16,56);Text(row,"Text",e.mood+"\n"+DateLabel(e.created)+" · selected by you",90,12,560,65,19);}
            Pagination(p,entries.Count,4,426,734);
            Text(p,"Meaning","Child choices and shared records, without scores.",52,772,600,30,16,false,Brand);
            Button(p,"BackToMood","My feelings",900,772,242,42,()=>Go("mood"));
        }
        private void CalmListView()
        {
            var p=Page("Soothing music","Give your feelings a gentle moment",Lime,"mood");
            for(int i=0;i<3;i++)
            {
                var card=Panel(p,"TrackCard"+i,52+i*370,170,350,530,Color.white);
                Art(card,"Art",Asset(trackArts[i]),20,20,310,230);
                Text(card,"Title",trackNames[i],20,262,310,82,25,true);
                Text(card,"Copy","Original offline melody · "+Duration(calmTracks[i].length),20,356,310,56,16,false,Muted);
                int index=i;Button(card,"ListenTrack_"+i,"Listen",20,450,310,56,()=>StartTrack(index),Lime);
            }
            EmotionNav(p);
        }
        private void StartTrack(int index)
        {
            selectedTrack=index;Go("calm");backgroundVoice.clip=calmTracks[index];backgroundVoice.loop=true;backgroundVoice.volume=Store.Data.volume*.55f;
            backgroundVoice.Play();trackPaused=false;repeat=true;Render();
        }
        private void CalmView()
        {
            var p=Page("Soothing music","Get comfortable and stay with the sound",Lime,"calmlist");
            var body=Panel(p,"Main",52,145,1090,565,Color.white);
            var art=Art(body,"Cover",Asset(trackArts[selectedTrack]),24,74,450,370);hero=art.rectTransform;
            Text(body,"NowPlaying",trackPaused?"Paused":"Now playing",508,24,550,30,17,true,Brand);
            Text(body,"TrackTitle",trackNames[selectedTrack],508,74,550,92,30,true);
            Text(body,"Copy","Breathe gently. Follow the sound at your own pace.",508,174,550,62,18,false,Muted);
            progress=Slider(body,"TrackProgress",508,246,550,0,v=>{if(backgroundVoice.clip!=null)backgroundVoice.time=Mathf.Min(v*backgroundVoice.clip.length,backgroundVoice.clip.length-.02f);});
            liveProgress=Text(body,"Time","",508,288,550,36,16,false,Muted);
            var play=Button(body,"TrackPlay",trackPaused?"Play":"Pause",508,344,170,56,()=>{if(trackPaused){if(backgroundVoice.time==0)backgroundVoice.Play();else backgroundVoice.UnPause();}else backgroundVoice.Pause();trackPaused=!trackPaused;playLabel.text=trackPaused?"Play":"Pause";});playLabel=play.GetComponentInChildren<TMP_Text>();
            Button(body,"TrackRepeat",repeat?"Repeat: on":"Repeat: off",692,344,180,56,()=>{repeat=!repeat;backgroundVoice.loop=repeat;Render();},Paper);
            bool fav=Store.Data.favoriteTracks.Contains(selectedTrack);Button(body,"TrackFavorite",fav?"Saved":"Favorite",886,344,172,56,()=>{if(fav)Store.Data.favoriteTracks.Remove(selectedTrack);else Store.Data.favoriteTracks.Add(selectedTrack);Persist();Render();},Paper);
            Text(body,"TimerLabel","Stop timer",508,404,550,22,14,false,Muted);
            Button(body,"Timer","1 min",508,434,124,48,()=>{timerEnd=Time.realtimeSinceStartupAsDouble+60;});
            Button(body,"Timer5","5 min",646,434,124,48,()=>{timerEnd=Time.realtimeSinceStartupAsDouble+300;});
            Button(body,"Timer15","15 min",784,434,124,48,()=>{timerEnd=Time.realtimeSinceStartupAsDouble+900;});
            Button(body,"CancelTimer","No timer",922,434,136,48,()=>timerEnd=0);
            Button(body,"ChooseTrack","Choose another track",508,492,550,48,()=>Go("calmlist"),Lime);
            EmotionNav(p);
        }
        private void SaveView()
        {
            var p=Page("Save my music","Give your little melody a name",Gold,"play");
            if(draft==null){Text(p,"Empty","No unsaved melody yet.",52,200,1090,80,28);Button(p,"NewRecording","Record a melody",52,310,1090,56,StartRecording,Lime);return;}
            var left=Panel(p,"Preview",52,145,560,565,Paper);Text(left,"Label","A new creation",24,24,512,36,20,true);
            Art(left,"Instrument",Asset(instruments[draft.instrument].art),24,82,512,220);
            Text(left,"Title","This melody is yours",24,328,512,45,28,true);
            NoteBars(left,draft,24,397,512,64);
            var preview=Button(left,"PreviewDraft","Play · "+instruments[draft.instrument].name,24,485,512,56,()=>{selectedCreation=draft;ToggleReplay();});playLabel=preview.GetComponentInChildren<TMP_Text>();
            var right=Panel(p,"SaveForm",636,145,506,565,Paper);
            Text(right,"NameLabel","Give it a name",24,24,458,42,27,true);
            titleField=Input(right,"CreationName",draft.title,"Name your melody",24,86,458);
            Text(right,"MoodLabel","Add a feeling (optional)",24,180,458,32,19);
            MoodChoices(right,24,224,creationMood,m=>{draft.title=titleField.text;creationMood=m;Render();},.69f);
            Button(right,"SaveCreation","Save to My music",24,430,458,56,SaveDraft,Brand,Color.white);
            Text(right,"Hint","Saved on this device. Listen again anytime.",24,504,458,40,16,false,Muted);
        }
        private void LibraryView()
        {
            var p=Page("My music","Keep every little creation",Gold,"play");
            Button(p,"AllMusic","All music",52,145,180,52,()=>{favoritesOnly=false;listPage=0;Render();},favoritesOnly?Color.white:Lime);
            Button(p,"Favorites","Favorites",248,145,180,52,()=>{favoritesOnly=true;listPage=0;Render();},favoritesOnly?Lime:Color.white);
            var search=Input(p,"Search",query,"Find a melody you love",452,145,690);search.onEndEdit.AddListener(text=>{query=text;listPage=0;Render();});
            var data=Store.Data.creations.Where(c=>(!favoritesOnly||c.favorite)&&(string.IsNullOrWhiteSpace(query)||c.title.IndexOf(query,StringComparison.OrdinalIgnoreCase)>=0)).Reverse().ToList();
            if(data.Count==0)Text(p,"Empty","No melodies here yet.\nRecord your first creation, or change the filter.",52,280,1090,150,28,true);
            for(int i=0;i<Mathf.Min(3,data.Count-listPage*3);i++)
            {
                var c=data[listPage*3+i];var card=Panel(p,"CreationCard"+i,52+i*370,222,350,470,Paper);
                Art(card,"Art",Asset(instruments[c.instrument].art),20,16,310,190);
                Text(card,"Name",c.title,20,220,310,76,24,true);Text(card,"Date",DateLabel(c.created)+"\n"+instruments[c.instrument].name+" · "+Duration(c.duration),20,302,310,70,16,false,Muted);
                Button(card,"OpenCreation_"+i,"Listen again",20,390,310,56,()=>{selectedCreation=c;Go("detail");});
            }
            Pagination(p,data.Count,3,52,724);
            Button(p,"RecordNew","Create new music",790,752,352,56,()=>Go("play"),Brand,Color.white);
        }
        private void DetailView()
        {
            var p=Page(selectedCreation==null?"My music":selectedCreation.title,"A sound worth keeping",Gold,"library");
            if(selectedCreation==null){Text(p,"Empty","Choose a saved creation first.",52,200,1090,100,28);return;}
            var c=selectedCreation;var player=Panel(p,"Player",52,145,712,565,Color.white);
            hero=Art(player,"Performance",Asset("freeMascot"),24,16,664,360).rectTransform;
            Text(player,"MediaType","Animated music replay · your recorded notes",24,380,664,32,16,false,Muted);
            progress=Slider(player,"ReplaySeek",24,430,664,0,SeekReplay);
            liveProgress=Text(player,"ReplayTime","00:00 / "+Duration(c.duration),24,476,440,30,17,false,Muted);
            var b=Button(player,"ReplayMusic",replaying&&!replayPaused?"Pause":"Play",496,480,192,56,ToggleReplay,Lime);playLabel=b.GetComponentInChildren<TMP_Text>();
            var story=Panel(p,"Story",788,145,354,565,Paper);
            Text(story,"Title",c.title,24,24,306,100,28,true);Text(story,"Metadata",DateLabel(c.created)+"\n"+instruments[c.instrument].name+"\n"+Duration(c.duration)+" · "+c.notes.Count+" notes",24,144,306,110,18,false,Muted);
            Text(story,"Mood","Your feeling\n"+(string.IsNullOrEmpty(c.mood)?"Not recorded":c.mood+" · self-reported"),24,280,306,85,20);
            Button(story,"FavoriteCreation",c.favorite?"Saved to favorites":"Save this moment",24,398,306,56,()=>{c.favorite=!c.favorite;Persist();Render();},Lime);
            Text(story,"Talk","Try together: can we make another ending?",24,480,306,64,18,false,Muted);
            Button(p,"MoreMusic","More creations",52,752,350,56,()=>Go("library"));
        }
        private void NoteBars(Transform p,Creation c,float x,float y,float w,float h)
        {
            if(c.notes.Count==0)return;
            foreach(var note in c.notes.Take(100))
            {float height=20+note.key*9;Panel(p,"NoteBar",x+note.time/Mathf.Max(.1f,c.duration)*(w-6),y+(h-height)/2,4,height,Brand);}
        }
        private void Stat(Transform p,string name,string value,string label,float x,float y,float w)
        {var c=Panel(p,name,x,y,w,126,Color.white);Text(c,"Value",value,20,18,w-40,48,30,true);Text(c,"Label",label,20,78,w-40,32,16,false,Muted);}
        private void MoodIcon(Transform p,int index,float x,float y,float size)
        {
            Color[] colors={Orange,Gold,ColorOf("E9D75E"),Lime};
            var circle=Panel(p,"MoodCircle",x,y,size,size,colors[index]);circle.GetComponent<Image>().sprite=circleSprite;circle.GetComponent<Image>().type=Image.Type.Simple;
            Art(circle,"Face",Asset(moodArts[index]),0,0,size,size);
        }
        private void Pagination(Transform p,int total,int size,float x,float y)
        {
            int pages=Mathf.Max(1,Mathf.CeilToInt(total/(float)size));listPage=Mathf.Clamp(listPage,0,pages-1);
            var prev=Button(p,"Previous","Previous",x,y,150,44,()=>{listPage--;Render();});prev.interactable=listPage>0;
            Text(p,"PageNumber",(listPage+1)+" / "+pages,x+168,y,100,44,18,false,Brand,TextAlignmentOptions.Center);
            var next=Button(p,"Next","Next",x+286,y,150,44,()=>{listPage++;Render();});next.interactable=listPage+1<pages;
        }
        private void PeriodButtons(Transform p)
        {int[] days={7,30,0};for(int i=0;i<3;i++){int day=days[i];Button(p,"Period_"+day,day==0?"All time":"Last "+day+" days",52+i*186,145,170,48,()=>{period=day;listPage=0;Render();},period==day?Lime:Color.white);}}
    }
}
