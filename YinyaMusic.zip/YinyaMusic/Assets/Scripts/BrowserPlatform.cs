using UnityEngine;
#if UNITY_WEBGL && !UNITY_EDITOR
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine.EventSystems;
using UnityEngine.Scripting;
#endif

namespace Yinya
{
    public static class BrowserPlatform
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")] private static extern void YinyaInstallAudioGesture();
        public static void Install()=>YinyaInstallAudioGesture();
#else
        public static void Install() { }
#endif
    }
#if UNITY_WEBGL && !UNITY_EDITOR
    public sealed class BrowserInputField : MonoBehaviour,IPointerClickHandler
    {
        public TMP_InputField field;
        public void OnPointerClick(PointerEventData data)=>BrowserInputReceiver.Open(field);
    }
    [Preserve]
    public sealed class BrowserInputReceiver : MonoBehaviour
    {
        [DllImport("__Internal")] private static extern void YinyaEditText(string value,string hint);
        private static BrowserInputReceiver instance;
        private TMP_InputField active;
        public static void Open(TMP_InputField field)
        {
            if(instance==null){instance=new GameObject("YinyaBrowserInput").AddComponent<BrowserInputReceiver>();DontDestroyOnLoad(instance.gameObject);}
            instance.active=field;WebGLInput.captureAllKeyboardInput=false;
            YinyaEditText(field.text,field.name=="Search"?"Find a melody":"Name your melody");
        }
        [Preserve] public void Commit(string text)
        {
            var field=active;active=null;WebGLInput.captureAllKeyboardInput=true;
            if(field==null)return;field.text=text;field.onEndEdit.Invoke(text);
        }
        [Preserve] public void Cancel(string unused){active=null;WebGLInput.captureAllKeyboardInput=true;}
    }
#endif
}
