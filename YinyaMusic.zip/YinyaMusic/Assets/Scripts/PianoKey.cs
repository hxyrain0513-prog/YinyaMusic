using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Collections.Generic;

namespace Yinya
{
    public sealed class PianoKey : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        public ToyInput input;
        public int key;
        public Image face;
        public Color normal;
        private Vector3 targetScale = Vector3.one;
        private readonly HashSet<int> pointers = new HashSet<int>();

        private void OnEnable() { input.KeyChanged += OnKey; }
        private void OnDisable()
        {
            input.KeyChanged -= OnKey;
            foreach (int pointer in pointers) input.ReleaseSource("touch-" + key + "-" + pointer);
            pointers.Clear();
            if (face != null) face.color = normal;
            transform.localScale = Vector3.one;
            targetScale = Vector3.one;
        }
        public void OnPointerDown(PointerEventData data)
        {
            pointers.Add(data.pointerId);
            input.SetKey(key, true, "touch-" + key + "-" + data.pointerId);
        }
        public void OnPointerUp(PointerEventData data)
        {
            pointers.Remove(data.pointerId);
            input.SetKey(key, false, "touch-" + key + "-" + data.pointerId);
        }
        private void OnKey(int index, bool down, double time)
        {
            if (index != key) return;
            face.color = down ? Color.Lerp(normal, Color.white, .48f) : normal;
            targetScale = down ? new Vector3(.96f, .96f, 1) : Vector3.one;
        }
        private void Update() => transform.localScale = Vector3.Lerp(transform.localScale, targetScale, 1 - Mathf.Exp(-22 * Time.unscaledDeltaTime));
    }
}
