mergeInto(LibraryManager.library, {
  YinyaStorageRead: function(backup) {
    var value = '';
    try {
      var qa = /(?:\?|&)qa=1(?:&|$)/.test(window.location.search);
      value = window.localStorage.getItem('YinyaOffline.v1' + (qa ? '.qa' : '') + (backup ? '.backup' : '')) || '';
    } catch (error) { value = '__UNAVAILABLE__'; }
    var size = lengthBytesUTF8(value) + 1;
    var buffer = _malloc(size);
    stringToUTF8(value, buffer, size);
    return buffer;
  },
  YinyaStorageWrite: function(pointer) {
    try {
      var value = UTF8ToString(pointer);
      var qa = /(?:\?|&)qa=1(?:&|$)/.test(window.location.search);
      var key = 'YinyaOffline.v1' + (qa ? '.qa' : '');
      var previous = window.localStorage.getItem(key);
      if (previous !== null) window.localStorage.setItem(key + '.backup', previous);
      window.localStorage.setItem(key, value);
      return 1;
    } catch (error) { return 0; }
  },
  YinyaInstallAudioGesture: function() {
    if (window.yinyaEnableAudio) return;
    var enable = function() {
      try {
        if (typeof WEBAudio !== 'undefined' && WEBAudio.audioContext) {
          WEBAudio.audioContext.resume().catch(function() {});
        }
      } catch (error) {}
    };
    window.yinyaEnableAudio = enable;
    document.addEventListener('pointerdown', enable, { passive: true });
    document.addEventListener('touchstart', enable, { passive: true });
    document.addEventListener('keydown', enable);
  },
  YinyaEditText: function(valuePointer, hintPointer) {
    if (document.getElementById('yinya-text-dialog')) return;
    var layer = document.createElement('div');
    layer.id = 'yinya-text-dialog';
    layer.style.cssText = 'position:fixed;inset:0;z-index:1000;background:#343a4870;display:grid;place-items:center;padding:20px;';
    var dialog = document.createElement('form');
    dialog.style.cssText = 'width:min(520px,90vw);padding:28px;border-radius:24px;background:#fff6e4;color:#343a48;font:18px system-ui;box-sizing:border-box;';
    var label = document.createElement('label');
    label.textContent = UTF8ToString(hintPointer);
    label.htmlFor = 'yinya-native-input';
    var input = document.createElement('input');
    input.id = 'yinya-native-input';input.type = 'text';input.maxLength = 60;input.value = UTF8ToString(valuePointer);
    input.style.cssText = 'display:block;width:100%;box-sizing:border-box;padding:15px;margin:18px 0 24px;border:2px solid #c8d74e;border-radius:14px;background:white;font:20px system-ui;color:#343a48;';
    var done = document.createElement('button');done.type = 'submit';done.textContent = 'Done';
    done.style.cssText = 'padding:14px 28px;border:0;border-radius:28px;background:#46566a;color:white;font:18px system-ui;';
    var cancel = document.createElement('button');cancel.type = 'button';cancel.textContent = 'Cancel';
    cancel.style.cssText = 'padding:14px 22px;margin-left:12px;border:0;border-radius:28px;background:white;color:#46566a;font:18px system-ui;';
    var close = function(method, value) {
      layer.remove();
      if (window.yinyaUnity) window.yinyaUnity.SendMessage('YinyaBrowserInput', method, value || '');
    };
    dialog.onsubmit = function(event) { event.preventDefault();close('Commit',input.value); };
    cancel.onclick = function() { close('Cancel',''); };
    dialog.append(label,input,done,cancel);layer.append(dialog);document.body.append(layer);
    input.focus();
  }
});
