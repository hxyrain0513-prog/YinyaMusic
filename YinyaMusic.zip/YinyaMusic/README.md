# Yinya Music 音乐互动 App

Unity 工程源码，支持不连接 Arduino 的音乐游戏、情绪记录、舒缓音乐与五键自由创作。

## 打开运行

1. 使用 Unity Hub 添加当前文件夹（包含 Assets、Packages、ProjectSettings 的目录）。
2. 原工程版本为 **Unity 2022.3.62f3c1**。首次打开等待依赖下载和资源导入；其他版本需先在副本中验证兼容性。
3. 打开 `Assets/Scenes/YinyaOffline.unity`，点击 Play；也可以执行 `Yinya > Build Offline App`。
4. 自由创作支持鼠标/触屏或数字键 1–5。无需 Arduino、MCP 或 Codex。

完整功能和已做的编辑器验证见 [离线互动版说明](README-离线互动版.md)。

## 工程结构

- Assets：场景、C# 脚本、插画、字体、音频、WebGL 模板。
- Packages：包依赖和锁定文件。
- ProjectSettings：项目设置与构建场景。
- Documentation：界面总览（如有）。

## iPad 浏览器方向

已包含浏览器触摸启用声音、网页输入框和浏览器本地保存适配，以及 `Yinya > Build iPad Browser Demo` 构建入口。需安装同版本 WebGL Build Support。
这些适配尚未完成 WebGL 构建及 iPad Safari 实机验证。本交付包是源码，不是已验证可运行的网页或 iPad 安装包。
GitHub 保存源码不会自动让 Unity 工程在网页上运行；GitHub Pages 需要另外构建并部署 WebGL 输出。

## 上传 GitHub

将本目录的内容放到仓库根目录，保留所有 `.meta` 文件及隐藏文件 `.gitignore`、`.gitattributes`。
推荐使用 GitHub Desktop 选择本目录作为本地仓库，再发布到自己的 GitHub 账号。
不要把 Library、Temp、Releases 或整个交付 ZIP 当作源码提交。

## 素材说明

界面素材来自项目提供的 Figma 设计；字体授权文件保留在 Assets 中，音频包含本项目生成的合成音及语音提示。
本包未新增开源许可证。公开发布前应确认原设计和素材的公开再分发权限。

本包不含 Unity 缓存、本机存档、测试数据、MCP 桥接或本机连接脚本；原始开发工程未修改。
